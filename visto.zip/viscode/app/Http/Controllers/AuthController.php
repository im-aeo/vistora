<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Http\Requests\Auth\LoginRequest;
use App\Providers\RouteServiceProvider;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Inertia\Inertia;
use Inertia\Response;
use Illuminate\Support\Facades\Redirect;

class AuthController extends Controller
{
    use \Illuminate\Foundation\Auth\AuthenticatesUsers;

    public function LoginIndex()
    {
        return Inertia::render('Authentication/Login');
        
    }
  
    public function LoginVal(LoginRequest $request): RedirectResponse
    {
        $request->authenticate();

        $request->session()->regenerate();

        return redirect()->intended(RouteServiceProvider::HOME)->with('message', 'You have Authenticated.');;
    }
    public function ForgotIndex()
    {
        return Inertia::render('Authentication/Forgot');
    }
  
    public function RegisterIndex()
    {
        return Inertia::render('Authentication/Create');
    }
  
    public function RegisterVal(Request $request): RedirectResponse
    {
        $request->validate([
            'name' => 'required|alpha_num|min:3|max:25|unique:'.User::class,
            'email' => 'required|string|email|max:255|unique:'.User::class,
            'password' => ['required', Rules\Password::defaults()],
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'status' => 'Hey, Im new to vistora.',
            'bio' => 'Greetings! Im new to vistora.',
        ]);

        event(new Registered($user));

        Auth::login($user);

        return redirect(RouteServiceProvider::HOME);
    }
  
    public function UserExit(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}