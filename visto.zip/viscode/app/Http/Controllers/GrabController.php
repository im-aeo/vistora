<?php

namespace App\Http\Controllers;

use App\Models\User;
//use App\Models\Group; //when groups are finished
use App\Models\Followers;
use App\Models\Status;
use App\Models\ForumReply;
use App\Models\ForumTopic;
use App\Models\ForumThread;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\DiffUsername;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

class GrabController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
  
    public function DashboardIndex()
    {
       
      $statuses = Status::where([ 
           ['creator_id', '!=', Auth::user()->id], 
           ['message', '!=', null]
          ])->orderBy('created_at', 'desc')->paginate(12)->through(function ($status) {
        return [
            'name' => $status->creator->name,
            'online' => $status->online,
            'timecreated' => $status->created_at,
            'message' => $status->message,
            'DateHum' => $status->DateHum,
           ];
      });
      
        return Inertia::render('Dashboard', [
            'slist' => $statuses
        ]);
        
    }
  
    public function DashboardVal(Request $request)
    {
        $this->validate($request, [
            'message' => ['max:124']
        ]);
      
        if ($request->message != Auth::user()->status()) {
            // Logging
            $status = new Status;
            $status->creator_id = Auth::user()->id;
            $status->message = $request->message;
            $status->save();
            $user = User::where('id', '=', Auth::user()->id)->first();
            $user->status = $request->message;
            $user->save();
        }

        return back()->with('message', 'Status has been changed.');
    }
  
    public function UserIndex()
    {
        $users = User::orderBy('updated_at', 'desc')->paginate(6)->through(function ($user) {
        return [
            'name' => $user->name,
            'staff' => $user->staff,
            'status' => $user->status,
            
           ];
      });
      
      
        return Inertia::render('Users/Index', [
            'users' => $users,
        ]);
    }
  
    public function ForumIndex($id)
    {
        // Official
        $section_one = ForumTopic::where([['is_staff_only_viewing', false],['section_id', 1]])->orderBy('id', 'ASC')->get();
        
        if (Auth::check() && Auth::user()->staff == 1)
            $section_one = ForumTopic::where([['section_id', 1]])->orderBy('id', 'ASC')->get();
      
        // Community
        $section_two = ForumTopic::where([['is_staff_only_viewing', false],['section_id', 2]])->orderBy('id', 'ASC')->get();
        
        if (Auth::check() && Auth::user()->staff == 1)
            $section_two = ForumTopic::where([['section_id', 2],['hidden', false]])->orderBy('id', 'ASC')->get();
      
        // Serious
        $section_three = ForumTopic::where([['is_staff_only_viewing', false],['hidden', false],['section_id', 3]])->orderBy('id', 'ASC')->get();
        
        if (Auth::check() && Auth::user()->staff == 1)
            $section_three = ForumTopic::where([['section_id', 3]])->orderBy('id', 'ASC')->get();
      
        // Post Rendering
        $topic = ForumTopic::where('id', '=', $id)->firstOrFail();

        if (!Auth::check() || !Auth::user()->staff == 1 && $topic->is_staff_only_viewing) abort(404);
      
        $posts = $topic->threads()->through(function ($post) {
        return [
            'name' => $post->title,
            'username' => $post->creator->name,
            'lastreply' => $post->creator->name,
            'message' => $post->body,
            'pinned' => $post->is_pinned,
            'locked' => $post->is_locked,
            'deleted' => $post->is_deleted,
            'DateHum' => $post->DateHum,
           ];
        });
      
        return Inertia::render('Forum/Index', [
            'topic' => $topic,
            'posts' => $posts,
            'section_one' => $section_one,
            'section_two' => $section_two,
            'section_three' => $section_three
        ]);
    }
  
    public function ForumCreate($id)
    {
        
       // SideBar Re-run
       // Official
        $section_one = ForumTopic::where([['is_staff_only_viewing', false],['section_id', 1]])->orderBy('id', 'ASC')->get();
        
        if (Auth::check() && Auth::user()->staff == 1)
            $section_one = ForumTopic::where([['section_id', 1]])->orderBy('id', 'ASC')->get();
      
        // Community
        $section_two = ForumTopic::where([['is_staff_only_viewing', false],['section_id', 2]])->orderBy('id', 'ASC')->get();
        
        if (Auth::check() && Auth::user()->staff == 1)
            $section_two = ForumTopic::where([['section_id', 2],['hidden', false]])->orderBy('id', 'ASC')->get();
      
        // Serious
        $section_three = ForumTopic::where([['is_staff_only_viewing', false],['hidden', false],['section_id', 3]])->orderBy('id', 'ASC')->get();
        
        if (Auth::check() && Auth::user()->staff == 1)
            $section_three = ForumTopic::where([['section_id', 3]])->orderBy('id', 'ASC')->get();
      
        // Post Rendering
        $topic = ForumTopic::where('id', '=', $id)->firstOrFail();
      
       // DB Rendering
       $topic = ForumTopic::where('id', '=', $id)->firstOrFail();

        return Inertia::render('Forum/Create', [
            'id' => $id,
            'topic' => $topic,
            'section_one' => $section_one,
            'section_two' => $section_two,
            'section_three' => $section_three
        ]);
    }
  
    public function ForumVal($id,Request $request)
    {
       $this->validate($request, [
            'title' => ['required','max:100'],
            'body' => ['required', 'min:3','max:7500']
        ]);
      
            $post = new ForumThread;
            $post->in_topic_id = $id;
            $post->creator_id = Auth::user()->id;
            $post->title = $request->title;
            $post->body = $request->body;
            $post->save();

        return redirect()->route('forum.post', $post->id)->with('message', 'Your post has been created.');
    }
  
    public function ProfileIndex($username)
    {
      $user = User::where('name', '=', $username);

        if (!$user->exists()) {
            $usernameHistory = DiffUsername::where('username', '=', $username);

            if (!$usernameHistory->exists()) abort(404);

            return redirect()->route('user.profile', $usernameHistory->first()->user->username);
        }

        $user = $user->first();
        //$friends = $user->friends()->take(6);
        //$groups = $user->groups()->take(6);

      /*
        if (Auth::check()) {
            $friendsArray = [];

            foreach ($user->friends() as $friend)
                $friendsArray[] = $friend->id;

            $areFriends = in_array(Auth::user()->id, $friendsArray);
            $isPending = Friend::where('is_pending', '=', true)->where(function($query) use($user) {
                $query->where([
                    ['receiver_id', '=', $user->id],
                    ['sender_id', '=', Auth::user()->id]
                ])->orWhere([
                    ['receiver_id', '=', Auth::user()->id],
                    ['sender_id', '=', $user->id]
                ]);
            })->first();
        }
        */
        return Inertia::render('Users/Profile', [
            'user' => $user,
            //'friends' => $friends,
            //'groups' => $groups,
            //'areFriends' => $areFriends ?? false,
            //'isPending' => $isPending ?? false
        ]);
    }
  
    public function IndexingIndex()
    {
        //
    }
  
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\group  $group
     * @return \Illuminate\Http\Response
     */
    public function show(group $group)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\group  $group
     * @return \Illuminate\Http\Response
     */
    public function edit(group $group)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\group  $group
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, group $group)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\group  $group
     * @return \Illuminate\Http\Response
     */
    public function destroy(group $group)
    {
        //
    }
}
