import { unref, withCtx, createVNode, createTextVNode, useSSRContext, mergeProps, resolveComponent, withModifiers, withDirectives, vModelText, openBlock, createBlock, toDisplayString, createCommentVNode, ref, vModelCheckbox, Fragment, renderList, createSSRApp, h as h$1 } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrRenderClass, ssrInterpolate, ssrRenderSlot, ssrIncludeBooleanAttr, ssrLooseContain, ssrRenderAttrs, ssrRenderList, ssrRenderStyle } from "vue/server-renderer";
import { Head, Link, useForm, usePage, createInertiaApp } from "@inertiajs/vue3";
import createServer from "@inertiajs/vue3/server";
import { renderToString } from "@vue/server-renderer";
const _sfc_main$h = {
  __name: "Layout",
  __ssrInlineRender: true,
  props: {
    title: String,
    isActive: false,
    showNavbar: true
  },
  setup(__props) {
    document.addEventListener("DOMContentLoaded", () => {
      (document.querySelectorAll(".notification .delete") || []).forEach(($delete) => {
        $notification = $delete.parentNode;
        $delete.addEventListener("click", () => {
          $notification.parentNode.removeChild($notification);
        });
      });
    });
    var notifications = new Notifications();
    notifications.init();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: __props.title }, null, _parent));
      _push(`<nav class="navbar is-spaced has-shadow"><div class="container"><div class="navbar-brand">`);
      _push(ssrRenderComponent(unref(Link), {
        class: "navbar-item",
        href: _ctx.route("Welcome")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img class="index-logo" src="/branding/flat_logo.svg" alt=""${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                class: "index-logo",
                src: "/branding/flat_logo.svg",
                alt: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<a${ssrRenderAttr("aria-expanded", __props.isActive)} class="${ssrRenderClass([{ "is-active": __props.isActive }, "navbar-burger"])}" role="button" aria-label="menu" data-target="collapse"><span aria-hidden="true"></span><span aria-hidden="true"></span><span aria-hidden="true"></span></a></div><div id="collapse" class="${ssrRenderClass([{ "is-active": __props.isActive }, "navbar-menu"])}"><div class="navbar-start">`);
      _push(ssrRenderComponent(unref(Link), {
        class: "navbar-item",
        href: _ctx.route("Welcome")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Dashboard`);
          } else {
            return [
              createTextVNode("Dashboard")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(unref(Link), {
        class: "navbar-item",
        href: _ctx.route("Store")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Store`);
          } else {
            return [
              createTextVNode("Store")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(unref(Link), {
        class: "navbar-item",
        href: _ctx.route("forum.page", { id: 1 })
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Forum`);
          } else {
            return [
              createTextVNode("Forum")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(unref(Link), {
        class: "navbar-item",
        href: _ctx.route("user.page")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Discover`);
          } else {
            return [
              createTextVNode("Discover")
            ];
          }
        }),
        _: 1
      }, _parent));
      if (_ctx.$page.props.auth.user && _ctx.$page.props.auth.user.staff == "1") {
        _push(ssrRenderComponent(unref(Link), {
          class: "navbar-item has-text-danger",
          href: _ctx.route("user.page")
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Admin`);
            } else {
              return [
                createTextVNode("Admin")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="navbar-item has-dropdown is-hoverable"><a class="navbar-link">More</a><div class="navbar-dropdown"><a class="navbar-item" href="#"><i class="fal fa-align-left"></i>  Public Indexing</a><a class="navbar-item" href="#"><i class="fad fa-people-arrows"></i>  Compete</a><a class="navbar-item" href="#"><i class="fad fa-dollar-sign"></i>  Promocodes</a><a class="navbar-item" href="#"><i class="fad fa-user-cog"></i>  Settings</a><hr class="navbar-divider">`);
      _push(ssrRenderComponent(unref(Link), { class: "navbar-item" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<i class="fab fa-twitter"${_scopeId}></i>  Twitter`);
          } else {
            return [
              createVNode("i", { class: "fab fa-twitter" }),
              createTextVNode("  Twitter")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(unref(Link), { class: "navbar-item" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<i class="fab fa-discord"${_scopeId}></i>  Discord`);
          } else {
            return [
              createVNode("i", { class: "fab fa-discord" }),
              createTextVNode("  Discord")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
      if (_ctx.$page.props.auth.user) {
        _push(`<div class="navbar-end"><div class="navbar-item"><a href="https://vistora.xyz/user/relations" class="navbar-item tooltip is-tooltip-bottom" data-tooltip="Relations"><i class="fad fa-handshake"></i></a><a href="https://vistora.xyz/user/trades" class="navbar-item tooltip is-tooltip-bottom" data-tooltip="Trades"><i class="fad fa-people-arrows"></i></a><a href="https://vistora.xyz/user/transactions" class="navbar-item tooltip is-tooltip-bottom" data-tooltip="Transactions">${ssrInterpolate(_ctx.$page.props.auth.user.vens)} Vens</a><div class="navbar-item has-dropdown is-hoverable"><a class="navbar-link"><span class="navbar-headshot is-hidden-mobile"><img class="navbar-headshot-image" src="/props/aeo_headshot.png" alt="Avatar Render"></span> ${ssrInterpolate(_ctx.$page.props.auth.user.name)}</a><div class="navbar-dropdown is-boxed is-right">`);
        _push(ssrRenderComponent(unref(Link), {
          class: "navbar-item",
          href: _ctx.route("user.profile", { username: _ctx.$page.props.auth.user.name })
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<i class="fad fa-user"${_scopeId}></i>  Profile`);
            } else {
              return [
                createVNode("i", { class: "fad fa-user" }),
                createTextVNode("  Profile")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`<a class="navbar-item" href="https://vistora.xyz/user/avatar"><i class="fad fa-sparkles"></i>  Avatar</a><a class="navbar-item" href="https://vistora.xyz/user/profile/aeo1/inventory"><i class="fad fa-suitcase"></i>  Inventory</a><a class="navbar-item" href="https://vistora.xyz/user/settings"><i class="fad fa-user-cog"></i>  Settings</a><hr class="navbar-divider">`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("auth.logout"),
          method: "post",
          class: "navbar-item has-text-danger"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<i class="fal fa-power-off"${_scopeId}></i>   Sign Out `);
            } else {
              return [
                createVNode("i", { class: "fal fa-power-off" }),
                createTextVNode("   Sign Out ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div></div></div>`);
      } else {
        _push(`<div class="navbar-end"><div class="navbar-item"><div class="buttons">`);
        _push(ssrRenderComponent(unref(Link), {
          class: "button is-light",
          href: _ctx.route("auth.login.page")
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Login`);
            } else {
              return [
                createTextVNode("Login")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(unref(Link), {
          class: "button is-info",
          href: _ctx.route("auth.register.page")
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<strong${_scopeId}>Hop in</strong>`);
            } else {
              return [
                createVNode("strong", null, "Hop in")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div></div>`);
      }
      _push(`</div></div></nav>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      if (_ctx.$page.props.flash.message) {
        _push(`<p class="notification is-success" data-close="self">${ssrInterpolate(_ctx.$page.props.flash.message)} <button class="button has-text-success">OK</button></p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<button class="chat-open-button button is-info is-rounded">Chat</button><div class="chat-popup" id="chat-form"><div class="box chat-form-container"><span class="delete is-pulled-right"></span><div class="title is-6 mb-2">Chat</div><hr class="mt-1 mb-1 w-100"><div class="chat-container"></div></div></div><hr><footer class="footer has-text-centered"><div class="content"><div class="is-size-5 has-text-weight-bold mb-3">Vistora</div><div class="columns is-centered is-mobile"><div class="column is-3"><div class="is-size-6 has-text-weight-semibold">Navigate</div>`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("Welcome")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Home`);
          } else {
            return [
              createTextVNode("Home")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<br>`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("Store")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Store`);
          } else {
            return [
              createTextVNode("Store")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<br>`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("forum.page", { id: 1 })
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Forum`);
          } else {
            return [
              createTextVNode("Forum")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<br></div><div class="column is-3"><div class="is-size-6 has-text-weight-semibold">Legal</div><a href="https://vistora.xyz/legal/terms">Terms of Service</a><br><a href="https://vistora.xyz/legal/privacy">Privacy</a><br></div><div class="column is-3"><div class="is-size-6 has-text-weight-semibold">Contact</div><a target="#" href="mailto:support@vistora.xyz">Email</a><br><a target="#" href="https://discord.gg/qwRYqbrBmG">Discord</a><br><a target="#" href="https://twitter.com/vistoraofficial">Twitter</a><br></div></div><div class="is-size-6">Vistora © - 2020-21</div></div></footer><!--]-->`);
    };
  }
};
const _sfc_setup$h = _sfc_main$h.setup;
_sfc_main$h.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/Layout.vue");
  return _sfc_setup$h ? _sfc_setup$h(props, ctx) : void 0;
};
const _sfc_main$g = {
  __name: "AccountDeleted",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$h, mergeProps({ title: "Welcome" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<section class="index-hero hero is-fullheight"${_scopeId}><div class="hero-body"${_scopeId}><div class="container"${_scopeId}><div class="columns is-centered"${_scopeId}><div class="column is-12 has-text-pulled-left"${_scopeId}><div class="title is-1 has-text-weight-normal mb-2"${_scopeId}> Your account has been deleted. </div><div class="title is-5 has-text-grey-light has-font-weight-light mb-3"${_scopeId}> Farewell. </div></div></div></div></div></section>`);
          } else {
            return [
              createVNode("section", { class: "index-hero hero is-fullheight" }, [
                createVNode("div", { class: "hero-body" }, [
                  createVNode("div", { class: "container" }, [
                    createVNode("div", { class: "columns is-centered" }, [
                      createVNode("div", { class: "column is-12 has-text-pulled-left" }, [
                        createVNode("div", { class: "title is-1 has-text-weight-normal mb-2" }, " Your account has been deleted. "),
                        createVNode("div", { class: "title is-5 has-text-grey-light has-font-weight-light mb-3" }, " Farewell. ")
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$g = _sfc_main$g.setup;
_sfc_main$g.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/AccountDeleted.vue");
  return _sfc_setup$g ? _sfc_setup$g(props, ctx) : void 0;
};
const __vite_glob_0_0 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main$g
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$f = {
  __name: "Create",
  __ssrInlineRender: true,
  props: {
    canResetPassword: Boolean,
    status: String
  },
  setup(__props) {
    const form = useForm({
      name: "",
      email: "",
      password: ""
    });
    const submit = () => {
      form.post(route("auth.register.validate"), {
        onFinish: () => form.reset("password")
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_center = resolveComponent("center");
      const _component_Link = resolveComponent("Link");
      _push(ssrRenderComponent(_sfc_main$h, mergeProps({ title: "Log in" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<section class="hero is-fullheight"${_scopeId}><div class="hero-body"${_scopeId}><div class="container"${_scopeId}><div class="columns is-centered"${_scopeId}><div class="column is-6-tablet is-5-desktop is-5-widescreen"${_scopeId}><div class="box"${_scopeId}><div class="is-size-5"${_scopeId}>Register</div><div class="is-size-6 has-text-grey-light mb-3"${_scopeId}>Create a new account and hop right in the action</div><form${_scopeId}><fieldset${_scopeId}><div class="field"${_scopeId}><label for="name" class="label"${_scopeId}>Username</label><div class="control has-icons-left"${_scopeId}><input id="name"${ssrRenderAttr("value", unref(form).name)} type="text" placeholder="Username" class="input"${_scopeId}><span class="icon is-small is-left"${_scopeId}><i class="fa fa-user"${_scopeId}></i></span>`);
            if (unref(form).errors.name) {
              _push2(`<div${_scopeId}>${ssrInterpolate(unref(form).errors.name)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="field"${_scopeId}><label for="email" class="label"${_scopeId}>E-mail</label><div class="control has-icons-left"${_scopeId}><input id="email"${ssrRenderAttr("value", unref(form).email)} type="email" placeholder="E-mail" class="input"${_scopeId}><span class="icon is-small is-left"${_scopeId}><i class="fa fa-user"${_scopeId}></i></span>`);
            if (unref(form).errors.email) {
              _push2(`<div${_scopeId}>${ssrInterpolate(unref(form).errors.email)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="field"${_scopeId}><label for="password" class="label"${_scopeId}>Password</label><div class="control has-icons-left"${_scopeId}><input id="password"${ssrRenderAttr("value", unref(form).password)} type="password" placeholder="Password" class="input"${_scopeId}><span class="icon is-small is-left"${_scopeId}><i class="fa fa-key"${_scopeId}></i></span>`);
            if (unref(form).errors.password) {
              _push2(`<div${_scopeId}>${ssrInterpolate(unref(form).errors.password)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="field"${_scopeId}><div class="buttons"${_scopeId}><button type="submit" class="button is-info"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""}${_scopeId}>Register</button></div></div></fieldset></form></div>`);
            _push2(ssrRenderComponent(_component_center, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_Link, {
                    href: _ctx.route("auth.login.page")
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Got an account?`);
                      } else {
                        return [
                          createTextVNode("Got an account?")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_Link, {
                      href: _ctx.route("auth.login.page")
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Got an account?")
                      ]),
                      _: 1
                    }, 8, ["href"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div></div></div></section>`);
          } else {
            return [
              createVNode("section", { class: "hero is-fullheight" }, [
                createVNode("div", { class: "hero-body" }, [
                  createVNode("div", { class: "container" }, [
                    createVNode("div", { class: "columns is-centered" }, [
                      createVNode("div", { class: "column is-6-tablet is-5-desktop is-5-widescreen" }, [
                        createVNode("div", { class: "box" }, [
                          createVNode("div", { class: "is-size-5" }, "Register"),
                          createVNode("div", { class: "is-size-6 has-text-grey-light mb-3" }, "Create a new account and hop right in the action"),
                          createVNode("form", {
                            onSubmit: withModifiers(submit, ["prevent"])
                          }, [
                            createVNode("fieldset", null, [
                              createVNode("div", { class: "field" }, [
                                createVNode("label", {
                                  for: "name",
                                  class: "label"
                                }, "Username"),
                                createVNode("div", { class: "control has-icons-left" }, [
                                  withDirectives(createVNode("input", {
                                    id: "name",
                                    "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                    type: "text",
                                    placeholder: "Username",
                                    class: "input"
                                  }, null, 8, ["onUpdate:modelValue"]), [
                                    [vModelText, unref(form).name]
                                  ]),
                                  createVNode("span", { class: "icon is-small is-left" }, [
                                    createVNode("i", { class: "fa fa-user" })
                                  ]),
                                  unref(form).errors.name ? (openBlock(), createBlock("div", { key: 0 }, toDisplayString(unref(form).errors.name), 1)) : createCommentVNode("", true)
                                ])
                              ]),
                              createVNode("div", { class: "field" }, [
                                createVNode("label", {
                                  for: "email",
                                  class: "label"
                                }, "E-mail"),
                                createVNode("div", { class: "control has-icons-left" }, [
                                  withDirectives(createVNode("input", {
                                    id: "email",
                                    "onUpdate:modelValue": ($event) => unref(form).email = $event,
                                    type: "email",
                                    placeholder: "E-mail",
                                    class: "input"
                                  }, null, 8, ["onUpdate:modelValue"]), [
                                    [vModelText, unref(form).email]
                                  ]),
                                  createVNode("span", { class: "icon is-small is-left" }, [
                                    createVNode("i", { class: "fa fa-user" })
                                  ]),
                                  unref(form).errors.email ? (openBlock(), createBlock("div", { key: 0 }, toDisplayString(unref(form).errors.email), 1)) : createCommentVNode("", true)
                                ])
                              ]),
                              createVNode("div", { class: "field" }, [
                                createVNode("label", {
                                  for: "password",
                                  class: "label"
                                }, "Password"),
                                createVNode("div", { class: "control has-icons-left" }, [
                                  withDirectives(createVNode("input", {
                                    id: "password",
                                    "onUpdate:modelValue": ($event) => unref(form).password = $event,
                                    type: "password",
                                    placeholder: "Password",
                                    class: "input"
                                  }, null, 8, ["onUpdate:modelValue"]), [
                                    [vModelText, unref(form).password]
                                  ]),
                                  createVNode("span", { class: "icon is-small is-left" }, [
                                    createVNode("i", { class: "fa fa-key" })
                                  ]),
                                  unref(form).errors.password ? (openBlock(), createBlock("div", { key: 0 }, toDisplayString(unref(form).errors.password), 1)) : createCommentVNode("", true)
                                ])
                              ]),
                              createVNode("div", { class: "field" }, [
                                createVNode("div", { class: "buttons" }, [
                                  createVNode("button", {
                                    type: "submit",
                                    class: "button is-info",
                                    disabled: unref(form).processing
                                  }, "Register", 8, ["disabled"])
                                ])
                              ])
                            ])
                          ], 40, ["onSubmit"])
                        ]),
                        createVNode(_component_center, null, {
                          default: withCtx(() => [
                            createVNode(_component_Link, {
                              href: _ctx.route("auth.login.page")
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Got an account?")
                              ]),
                              _: 1
                            }, 8, ["href"])
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$f = _sfc_main$f.setup;
_sfc_main$f.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Authentication/Create.vue");
  return _sfc_setup$f ? _sfc_setup$f(props, ctx) : void 0;
};
const __vite_glob_0_1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main$f
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$e = {
  __name: "Forgot",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_center = resolveComponent("center");
      _push(ssrRenderComponent(_sfc_main$h, mergeProps({ title: "Reset Password" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<section class="hero is-fullheight"${_scopeId}><div class="hero-body"${_scopeId}><div class="container"${_scopeId}><div class="columns is-centered"${_scopeId}><div class="column is-6-tablet is-5-desktop is-5-widescreen"${_scopeId}><div class="box"${_scopeId}><div class="is-size-5"${_scopeId}>Account Recovery</div><div class="is-size-6 has-text-grey-light mb-3"${_scopeId}>Reset your password</div><form${_scopeId}><fieldset${_scopeId}><div class="field"${_scopeId}><label for="username" class="label"${_scopeId}>E-mail</label><div class="control has-icons-left"${_scopeId}><input type="text" placeholder="Email" class="input"${_scopeId}><span class="icon is-small is-left"${_scopeId}><i class="fas fa-envelope"${_scopeId}></i></span></div></div></fieldset></form></div>`);
            _push2(ssrRenderComponent(_component_center, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<a${ssrRenderAttr("href", _ctx.route("auth.login.page"))}${_scopeId2}>Already have an account?</a>`);
                } else {
                  return [
                    createVNode("a", {
                      href: _ctx.route("auth.login.page")
                    }, "Already have an account?", 8, ["href"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div></div></div></section>`);
          } else {
            return [
              createVNode("section", { class: "hero is-fullheight" }, [
                createVNode("div", { class: "hero-body" }, [
                  createVNode("div", { class: "container" }, [
                    createVNode("div", { class: "columns is-centered" }, [
                      createVNode("div", { class: "column is-6-tablet is-5-desktop is-5-widescreen" }, [
                        createVNode("div", { class: "box" }, [
                          createVNode("div", { class: "is-size-5" }, "Account Recovery"),
                          createVNode("div", { class: "is-size-6 has-text-grey-light mb-3" }, "Reset your password"),
                          createVNode("form", {
                            onSubmit: withModifiers(_ctx.submit, ["prevent"])
                          }, [
                            createVNode("fieldset", null, [
                              createVNode("div", { class: "field" }, [
                                createVNode("label", {
                                  for: "username",
                                  class: "label"
                                }, "E-mail"),
                                createVNode("div", { class: "control has-icons-left" }, [
                                  createVNode("input", {
                                    type: "text",
                                    placeholder: "Email",
                                    class: "input"
                                  }),
                                  createVNode("span", { class: "icon is-small is-left" }, [
                                    createVNode("i", { class: "fas fa-envelope" })
                                  ])
                                ])
                              ])
                            ])
                          ], 40, ["onSubmit"])
                        ]),
                        createVNode(_component_center, null, {
                          default: withCtx(() => [
                            createVNode("a", {
                              href: _ctx.route("auth.login.page")
                            }, "Already have an account?", 8, ["href"])
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$e = _sfc_main$e.setup;
_sfc_main$e.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Authentication/Forgot.vue");
  return _sfc_setup$e ? _sfc_setup$e(props, ctx) : void 0;
};
const __vite_glob_0_2 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main$e
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$d = {
  __name: "Login",
  __ssrInlineRender: true,
  props: {
    canResetPassword: Boolean,
    status: String
  },
  setup(__props) {
    const ConfirmingAuth = ref(false);
    const form = useForm({
      name: "",
      password: "",
      remember: false
    });
    const submit = () => {
      form.transform((data) => ({
        ...data,
        remember: form.remember ? "on" : ""
      })).post(route("auth.login.validate"), {
        onFinish: () => form.reset("password")
      });
    };
    const ConfirmUserAuth = () => {
      ConfirmingAuth.value = true;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_center = resolveComponent("center");
      const _component_Link = resolveComponent("Link");
      _push(ssrRenderComponent(_sfc_main$h, mergeProps({ title: "Log in" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<section class="hero is-fullheight"${_scopeId}><div class="hero-body"${_scopeId}><div class="container"${_scopeId}><div class="columns is-centered"${_scopeId}><div class="column is-6-tablet is-5-desktop is-5-widescreen"${_scopeId}><div class="box"${_scopeId}><div class="is-size-5"${_scopeId}>Login</div><div class="is-size-6 has-text-grey-light mb-3"${_scopeId}>Lets continue from where you left</div><form${_scopeId}><fieldset${_scopeId}><div class="field"${_scopeId}><label for="name" class="label"${_scopeId}>Username</label><div class="control has-icons-left"${_scopeId}><input id="name"${ssrRenderAttr("value", unref(form).name)} type="text" placeholder="Username" class="input"${_scopeId}><span class="icon is-small is-left"${_scopeId}><i class="fa fa-user"${_scopeId}></i></span>`);
            if (unref(form).errors.name) {
              _push2(`<div${_scopeId}>${ssrInterpolate(unref(form).errors.name)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="field"${_scopeId}><label for="password" class="label"${_scopeId}>Password</label><div class="control has-icons-left"${_scopeId}><input id="password"${ssrRenderAttr("value", unref(form).password)} type="password" placeholder="Password" class="input"${_scopeId}><span class="icon is-small is-left"${_scopeId}><i class="fa fa-key"${_scopeId}></i></span>`);
            if (unref(form).errors.password) {
              _push2(`<div${_scopeId}>${ssrInterpolate(unref(form).errors.password)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="field"${_scopeId}><label class="checkbox"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(form).remember) ? ssrLooseContain(unref(form).remember, null) : unref(form).remember) ? " checked" : ""}${_scopeId}>Remember me</label></div><div class="field"${_scopeId}><div class="buttons"${_scopeId}><button type="submit" class="${ssrRenderClass([{ "is-loading": ConfirmingAuth.value }, "button is-info"])}"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""}${_scopeId}>Login</button><a${ssrRenderAttr("href", _ctx.route("auth.forgot.page"))} class="button"${_scopeId}>Forgot?</a></div></div></fieldset></form></div>`);
            _push2(ssrRenderComponent(_component_center, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_Link, {
                    href: _ctx.route("auth.register.page")
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`No account?`);
                      } else {
                        return [
                          createTextVNode("No account?")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_Link, {
                      href: _ctx.route("auth.register.page")
                    }, {
                      default: withCtx(() => [
                        createTextVNode("No account?")
                      ]),
                      _: 1
                    }, 8, ["href"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div></div></div></section>`);
          } else {
            return [
              createVNode("section", { class: "hero is-fullheight" }, [
                createVNode("div", { class: "hero-body" }, [
                  createVNode("div", { class: "container" }, [
                    createVNode("div", { class: "columns is-centered" }, [
                      createVNode("div", { class: "column is-6-tablet is-5-desktop is-5-widescreen" }, [
                        createVNode("div", { class: "box" }, [
                          createVNode("div", { class: "is-size-5" }, "Login"),
                          createVNode("div", { class: "is-size-6 has-text-grey-light mb-3" }, "Lets continue from where you left"),
                          createVNode("form", {
                            onSubmit: withModifiers(submit, ["prevent"])
                          }, [
                            createVNode("fieldset", null, [
                              createVNode("div", { class: "field" }, [
                                createVNode("label", {
                                  for: "name",
                                  class: "label"
                                }, "Username"),
                                createVNode("div", { class: "control has-icons-left" }, [
                                  withDirectives(createVNode("input", {
                                    id: "name",
                                    "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                    type: "text",
                                    placeholder: "Username",
                                    class: "input"
                                  }, null, 8, ["onUpdate:modelValue"]), [
                                    [vModelText, unref(form).name]
                                  ]),
                                  createVNode("span", { class: "icon is-small is-left" }, [
                                    createVNode("i", { class: "fa fa-user" })
                                  ]),
                                  unref(form).errors.name ? (openBlock(), createBlock("div", { key: 0 }, toDisplayString(unref(form).errors.name), 1)) : createCommentVNode("", true)
                                ])
                              ]),
                              createVNode("div", { class: "field" }, [
                                createVNode("label", {
                                  for: "password",
                                  class: "label"
                                }, "Password"),
                                createVNode("div", { class: "control has-icons-left" }, [
                                  withDirectives(createVNode("input", {
                                    id: "password",
                                    "onUpdate:modelValue": ($event) => unref(form).password = $event,
                                    type: "password",
                                    placeholder: "Password",
                                    class: "input"
                                  }, null, 8, ["onUpdate:modelValue"]), [
                                    [vModelText, unref(form).password]
                                  ]),
                                  createVNode("span", { class: "icon is-small is-left" }, [
                                    createVNode("i", { class: "fa fa-key" })
                                  ]),
                                  unref(form).errors.password ? (openBlock(), createBlock("div", { key: 0 }, toDisplayString(unref(form).errors.password), 1)) : createCommentVNode("", true)
                                ])
                              ]),
                              createVNode("div", { class: "field" }, [
                                createVNode("label", { class: "checkbox" }, [
                                  withDirectives(createVNode("input", {
                                    type: "checkbox",
                                    "onUpdate:modelValue": ($event) => unref(form).remember = $event
                                  }, null, 8, ["onUpdate:modelValue"]), [
                                    [vModelCheckbox, unref(form).remember]
                                  ]),
                                  createTextVNode("Remember me")
                                ])
                              ]),
                              createVNode("div", { class: "field" }, [
                                createVNode("div", { class: "buttons" }, [
                                  createVNode("button", {
                                    type: "submit",
                                    class: ["button is-info", { "is-loading": ConfirmingAuth.value }],
                                    disabled: unref(form).processing,
                                    onClick: ConfirmUserAuth
                                  }, "Login", 10, ["disabled"]),
                                  createVNode("a", {
                                    href: _ctx.route("auth.forgot.page"),
                                    class: "button"
                                  }, "Forgot?", 8, ["href"])
                                ])
                              ])
                            ])
                          ], 40, ["onSubmit"])
                        ]),
                        createVNode(_component_center, null, {
                          default: withCtx(() => [
                            createVNode(_component_Link, {
                              href: _ctx.route("auth.register.page")
                            }, {
                              default: withCtx(() => [
                                createTextVNode("No account?")
                              ]),
                              _: 1
                            }, 8, ["href"])
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$d = _sfc_main$d.setup;
_sfc_main$d.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Authentication/Login.vue");
  return _sfc_setup$d ? _sfc_setup$d(props, ctx) : void 0;
};
const __vite_glob_0_3 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main$d
}, Symbol.toStringTag, { value: "Module" }));
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const _sfc_main$c = {
  components: {
    Link
  },
  props: {
    pagedata: {
      type: Object,
      required: true,
      default: () => ({
        current_page: 0,
        last_page: 0,
        total: 0
      })
    }
  },
  methods: {
    getPageClick(page) {
      this.$emit("page-clicked", page);
    }
  }
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Link = resolveComponent("Link");
  _push(`<nav${ssrRenderAttrs(mergeProps({ class: "pagination is-centered" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_Link, {
    class: "pagination-previous is-hidden-mobile",
    href: $options.getPageClick($props.pagedata.current_page - 1),
    style: $props.pagedata.current_page > 1 ? null : { display: "none" }
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<i class="fa fa-angle-double-left" aria-hidden="true"${_scopeId}></i>`);
      } else {
        return [
          createVNode("i", {
            class: "fa fa-angle-double-left",
            "aria-hidden": "true"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_Link, {
    class: "pagination-next is-hidden-mobile",
    href: $options.getPageClick($props.pagedata.current_page + 1),
    style: $props.pagedata.current_page < $props.pagedata.last_page ? null : { display: "none" }
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<i class="fa fa-angle-double-right" aria-hidden="true"${_scopeId}></i>`);
      } else {
        return [
          createVNode("i", {
            class: "fa fa-angle-double-right",
            "aria-hidden": "true"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<ul class="pagination-list"><!--[-->`);
  ssrRenderList($props.pagedata.last_page, (page) => {
    _push(`<li>`);
    _push(ssrRenderComponent(_component_Link, {
      class: ["pagination-link", { "is-current": $props.pagedata.current_page == page }],
      href: $options.getPageClick(page)
    }, {
      default: withCtx((_, _push2, _parent2, _scopeId) => {
        if (_push2) {
          _push2(`${ssrInterpolate(page)}`);
        } else {
          return [
            createTextVNode(toDisplayString(page), 1)
          ];
        }
      }),
      _: 2
    }, _parent));
    _push(`</li>`);
  });
  _push(`<!--]--></ul></nav>`);
}
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Pagination.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const Aeopage = /* @__PURE__ */ _export_sfc(_sfc_main$c, [["ssrRender", _sfc_ssrRender$1]]);
const __default__$4 = {
  props: {
    slist: Object
  }
};
const _sfc_main$b = /* @__PURE__ */ Object.assign(__default__$4, {
  __name: "Dashboard",
  __ssrInlineRender: true,
  setup(__props) {
    const form = useForm({
      message: ""
    });
    const submit = () => {
      form.transform((data) => ({
        ...data,
        remember: form.remember ? "on" : ""
      })).post(route("my.dashboard.validate"), {
        onFinish: () => form.reset("message")
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Link = resolveComponent("Link");
      _push(ssrRenderComponent(_sfc_main$h, mergeProps({ title: "Dashboard" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container"${_scopeId}><section class="section"${_scopeId}><div class="columns is-centered"${_scopeId}><div class="column is-3"${_scopeId}><div class="dashboard-card card"${_scopeId}><div class="dashboard-header has-background-info"${_scopeId}><div class="dashboard-avatar"${_scopeId}><img class="" src="/props/aeo_headshot.png" alt="Avatar Render"${_scopeId}></div></div><div class="dashboard-card-body mt-4"${_scopeId}><div class="is-size-6 has-text-centered has-text-weight-semibold"${_scopeId}>${ssrInterpolate(_ctx.$page.props.auth.user.name)}</div></div></div></div><div class="column is-7"${_scopeId}><div class="block"${_scopeId}><form${_scopeId}><fieldset${_scopeId}><div class="field has-addons mb-0"${_scopeId}><div class="control is-expanded"${_scopeId}><input type="text" class="input" id="message"${ssrRenderAttr("value", unref(form).message)} placeholder="What&#39;s up?"${_scopeId}>`);
            if (unref(form).errors.message) {
              _push2(`<div${_scopeId}>${ssrInterpolate(unref(form).errors.message)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="control"${_scopeId}><button class="button is-info is-rounded"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""}${_scopeId}>Update</button></div></div></fieldset></form></div><div class="block"${_scopeId}><!--[-->`);
            ssrRenderList(__props.slist.data, (status) => {
              _push2(`<article class="media is-align-items-center"${_scopeId}><div class="media-left"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Link, {
                href: _ctx.route("user.profile", { username: status.name })
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<figure class="headshot image is-48x48"${_scopeId2}><img class="is-rounded" src="/props/aeo_headshot.png" alt="Avatar Render"${_scopeId2}><div class="status-circle-online"${_scopeId2}></div></figure>`);
                  } else {
                    return [
                      createVNode("figure", { class: "headshot image is-48x48" }, [
                        createVNode("img", {
                          class: "is-rounded",
                          src: "/props/aeo_headshot.png",
                          alt: "Avatar Render"
                        }),
                        createVNode("div", { class: "status-circle-online" })
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</div><div class="box has-shadow-small media-content"${_scopeId}><div class="content"${_scopeId}><div class="is-size-7 has-text-grey-light"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Link, {
                href: _ctx.route("user.profile", { username: status.name })
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(status.name)}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(status.name), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`  <span class="has-text-weight-semibold tooltip is-tooltip-top" data-tooltip="{{ status.created_at }}"${_scopeId}>${ssrInterpolate(status.DateHum)}</span></div>${ssrInterpolate(status.message)}</div></div></article>`);
            });
            _push2(`<!--]-->`);
            _push2(ssrRenderComponent(Aeopage, {
              links: __props.slist.links
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div></section></div>`);
          } else {
            return [
              createVNode("div", { class: "container" }, [
                createVNode("section", { class: "section" }, [
                  createVNode("div", { class: "columns is-centered" }, [
                    createVNode("div", { class: "column is-3" }, [
                      createVNode("div", { class: "dashboard-card card" }, [
                        createVNode("div", { class: "dashboard-header has-background-info" }, [
                          createVNode("div", { class: "dashboard-avatar" }, [
                            createVNode("img", {
                              class: "",
                              src: "/props/aeo_headshot.png",
                              alt: "Avatar Render"
                            })
                          ])
                        ]),
                        createVNode("div", { class: "dashboard-card-body mt-4" }, [
                          createVNode("div", { class: "is-size-6 has-text-centered has-text-weight-semibold" }, toDisplayString(_ctx.$page.props.auth.user.name), 1)
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "column is-7" }, [
                      createVNode("div", { class: "block" }, [
                        createVNode("form", {
                          onSubmit: withModifiers(submit, ["prevent"])
                        }, [
                          createVNode("fieldset", null, [
                            createVNode("div", { class: "field has-addons mb-0" }, [
                              createVNode("div", { class: "control is-expanded" }, [
                                withDirectives(createVNode("input", {
                                  type: "text",
                                  class: "input",
                                  id: "message",
                                  "onUpdate:modelValue": ($event) => unref(form).message = $event,
                                  placeholder: "What's up?"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).message]
                                ]),
                                unref(form).errors.message ? (openBlock(), createBlock("div", { key: 0 }, toDisplayString(unref(form).errors.message), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "control" }, [
                                createVNode("button", {
                                  class: "button is-info is-rounded",
                                  disabled: unref(form).processing
                                }, "Update", 8, ["disabled"])
                              ])
                            ])
                          ])
                        ], 40, ["onSubmit"])
                      ]),
                      createVNode("div", { class: "block" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.slist.data, (status) => {
                          return openBlock(), createBlock("article", {
                            class: "media is-align-items-center",
                            key: status.id
                          }, [
                            createVNode("div", { class: "media-left" }, [
                              createVNode(_component_Link, {
                                href: _ctx.route("user.profile", { username: status.name })
                              }, {
                                default: withCtx(() => [
                                  createVNode("figure", { class: "headshot image is-48x48" }, [
                                    createVNode("img", {
                                      class: "is-rounded",
                                      src: "/props/aeo_headshot.png",
                                      alt: "Avatar Render"
                                    }),
                                    createVNode("div", { class: "status-circle-online" })
                                  ])
                                ]),
                                _: 2
                              }, 1032, ["href"])
                            ]),
                            createVNode("div", { class: "box has-shadow-small media-content" }, [
                              createVNode("div", { class: "content" }, [
                                createVNode("div", { class: "is-size-7 has-text-grey-light" }, [
                                  createVNode(_component_Link, {
                                    href: _ctx.route("user.profile", { username: status.name })
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(toDisplayString(status.name), 1)
                                    ]),
                                    _: 2
                                  }, 1032, ["href"]),
                                  createTextVNode("  "),
                                  createVNode("span", {
                                    class: "has-text-weight-semibold tooltip is-tooltip-top",
                                    "data-tooltip": "{{ status.created_at }}"
                                  }, toDisplayString(status.DateHum), 1)
                                ]),
                                createTextVNode(toDisplayString(status.message), 1)
                              ])
                            ])
                          ]);
                        }), 128)),
                        createVNode(Aeopage, {
                          links: __props.slist.links
                        }, null, 8, ["links"])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Dashboard.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const __vite_glob_0_4 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main$b
}, Symbol.toStringTag, { value: "Module" }));
const __default__$3 = {
  props: {
    topic: Object,
    title: Object,
    id: Number,
    section_one: Object,
    section_two: Object,
    section_three: Object
  }
};
const _sfc_main$a = /* @__PURE__ */ Object.assign(__default__$3, {
  __name: "Create",
  __ssrInlineRender: true,
  setup(__props) {
    const form = useForm({
      id: "",
      title: "",
      body: ""
    });
    const submit = () => {
      form.transform((data) => ({
        ...data,
        remember: form.remember ? "on" : ""
      })).post(route("forum.create.validate"), {
        onFinish: () => form.reset("message")
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$h, mergeProps({ title: "Create a post" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container"${_scopeId}><section class="section"${_scopeId}><div class="container"${_scopeId}><div class="columns"${_scopeId}><div class="column is-3"${_scopeId}><span slot="secondary"${_scopeId}><div class="title"${_scopeId}>${ssrInterpolate(__props.topic.name)}</div><div class="subtitle is-6 has-text-grey-light"${_scopeId}>${ssrInterpolate(__props.topic.description)}</div><aside class="menu"${_scopeId}><p class="menu-label"${_scopeId}>Official</p><ul class="menu-list"${_scopeId}><!--[-->`);
            ssrRenderList(__props.section_one, (Official) => {
              _push2(`<li${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Link), {
                href: _ctx.route("forum.page", { id: Official.id })
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    if (Official.is_staff_only_posting == "1") {
                      _push3(`<i class="fas fa-lock"${_scopeId2}></i>`);
                    } else {
                      _push3(`<!---->`);
                    }
                    _push3(` ${ssrInterpolate(Official.name)}`);
                  } else {
                    return [
                      Official.is_staff_only_posting == "1" ? (openBlock(), createBlock("i", {
                        key: 0,
                        class: "fas fa-lock"
                      })) : createCommentVNode("", true),
                      createTextVNode(" " + toDisplayString(Official.name), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</li>`);
            });
            _push2(`<!--]--><p class="menu-label"${_scopeId}>Community</p><!--[-->`);
            ssrRenderList(__props.section_two, (Community) => {
              _push2(`<li${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Link), {
                href: _ctx.route("forum.page", { id: Community.id })
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(Community.name)}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(Community.name), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</li>`);
            });
            _push2(`<!--]--><p class="menu-label"${_scopeId}>Serious</p><!--[-->`);
            ssrRenderList(__props.section_three, (Serious) => {
              _push2(`<li${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Link), {
                href: _ctx.route("forum.page", { id: Serious.id })
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(Serious.name)}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(Serious.name), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</li>`);
            });
            _push2(`<!--]--></ul></aside></span></div><div class="column is-9"${_scopeId}><div class="title"${_scopeId}>Create</div><div class="subtitle is-6 has-text-grey-light"${_scopeId}>Create an eye-catching post. Make sure you post in the appropiate sub-forum and that your post does not break any site rules.</div><div class="box"${_scopeId}><form${_scopeId}><input type="hidden" name="id" value="{{ topic.id }}"${_scopeId}><div class="field"${_scopeId}><div class="control"${_scopeId}><div class="has-text-weight-bold"${_scopeId}>Post Title</div><input class="input" type="text" name="title"${ssrRenderAttr("value", unref(form).title)} placeholder="Title" maxlength="64"${_scopeId}></div></div><div class="field"${_scopeId}><div class="control"${_scopeId}><div class="has-text-weight-bold"${_scopeId}>Post Content</div><textarea class="textarea" name="body" placeholder="Body" maxlength="4096"${_scopeId}>${ssrInterpolate(unref(form).body)}</textarea></div></div><div class="field"${_scopeId}><div class="control"${_scopeId}><button class="button is-link"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""}${_scopeId}>Create</button></div></div></form></div></div></div></div></section></div>`);
          } else {
            return [
              createVNode("div", { class: "container" }, [
                createVNode("section", { class: "section" }, [
                  createVNode("div", { class: "container" }, [
                    createVNode("div", { class: "columns" }, [
                      createVNode("div", { class: "column is-3" }, [
                        createVNode("span", { slot: "secondary" }, [
                          createVNode("div", { class: "title" }, toDisplayString(__props.topic.name), 1),
                          createVNode("div", { class: "subtitle is-6 has-text-grey-light" }, toDisplayString(__props.topic.description), 1),
                          createVNode("aside", { class: "menu" }, [
                            createVNode("p", { class: "menu-label" }, "Official"),
                            createVNode("ul", { class: "menu-list" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(__props.section_one, (Official) => {
                                return openBlock(), createBlock("li", null, [
                                  createVNode(unref(Link), {
                                    href: _ctx.route("forum.page", { id: Official.id })
                                  }, {
                                    default: withCtx(() => [
                                      Official.is_staff_only_posting == "1" ? (openBlock(), createBlock("i", {
                                        key: 0,
                                        class: "fas fa-lock"
                                      })) : createCommentVNode("", true),
                                      createTextVNode(" " + toDisplayString(Official.name), 1)
                                    ]),
                                    _: 2
                                  }, 1032, ["href"])
                                ]);
                              }), 256)),
                              createVNode("p", { class: "menu-label" }, "Community"),
                              (openBlock(true), createBlock(Fragment, null, renderList(__props.section_two, (Community) => {
                                return openBlock(), createBlock("li", null, [
                                  createVNode(unref(Link), {
                                    href: _ctx.route("forum.page", { id: Community.id })
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(toDisplayString(Community.name), 1)
                                    ]),
                                    _: 2
                                  }, 1032, ["href"])
                                ]);
                              }), 256)),
                              createVNode("p", { class: "menu-label" }, "Serious"),
                              (openBlock(true), createBlock(Fragment, null, renderList(__props.section_three, (Serious) => {
                                return openBlock(), createBlock("li", null, [
                                  createVNode(unref(Link), {
                                    href: _ctx.route("forum.page", { id: Serious.id })
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(toDisplayString(Serious.name), 1)
                                    ]),
                                    _: 2
                                  }, 1032, ["href"])
                                ]);
                              }), 256))
                            ])
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "column is-9" }, [
                        createVNode("div", { class: "title" }, "Create"),
                        createVNode("div", { class: "subtitle is-6 has-text-grey-light" }, "Create an eye-catching post. Make sure you post in the appropiate sub-forum and that your post does not break any site rules."),
                        createVNode("div", { class: "box" }, [
                          createVNode("form", {
                            onSubmit: withModifiers(submit, ["prevent"])
                          }, [
                            createVNode("input", {
                              type: "hidden",
                              name: "id",
                              value: "{{ topic.id }}"
                            }),
                            createVNode("div", { class: "field" }, [
                              createVNode("div", { class: "control" }, [
                                createVNode("div", { class: "has-text-weight-bold" }, "Post Title"),
                                withDirectives(createVNode("input", {
                                  class: "input",
                                  type: "text",
                                  name: "title",
                                  "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                  placeholder: "Title",
                                  maxlength: "64"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).title]
                                ])
                              ])
                            ]),
                            createVNode("div", { class: "field" }, [
                              createVNode("div", { class: "control" }, [
                                createVNode("div", { class: "has-text-weight-bold" }, "Post Content"),
                                withDirectives(createVNode("textarea", {
                                  class: "textarea",
                                  name: "body",
                                  "onUpdate:modelValue": ($event) => unref(form).body = $event,
                                  placeholder: "Body",
                                  maxlength: "4096"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).body]
                                ])
                              ])
                            ]),
                            createVNode("div", { class: "field" }, [
                              createVNode("div", { class: "control" }, [
                                createVNode("button", {
                                  class: "button is-link",
                                  disabled: unref(form).processing
                                }, "Create", 8, ["disabled"])
                              ])
                            ])
                          ], 40, ["onSubmit"])
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Forum/Create.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const __vite_glob_0_5 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main$a
}, Symbol.toStringTag, { value: "Module" }));
const __default__$2 = {
  props: {
    topic: Object,
    posts: Object,
    section_one: Object,
    section_two: Object,
    section_three: Object
  }
};
const _sfc_main$9 = /* @__PURE__ */ Object.assign(__default__$2, {
  __name: "Index",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Link = resolveComponent("Link");
      _push(ssrRenderComponent(_sfc_main$h, mergeProps({ title: "Forum" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container"${_scopeId}><section class="section"${_scopeId}><div class="columns"${_scopeId}><div class="column is-3"${_scopeId}><span slot="secondary"${_scopeId}><div class="title"${_scopeId}>${ssrInterpolate(__props.topic.name)}</div><div class="subtitle is-6 has-text-grey-light"${_scopeId}>${ssrInterpolate(__props.topic.description)}</div><div class="buttons"${_scopeId}>`);
            if (_ctx.$page.props.auth.user.staff >= "1" && __props.topic.is_staff_only_posting == "1") {
              _push2(ssrRenderComponent(_component_Link, {
                class: "button is-info is-rounded is-fullwidth",
                href: _ctx.route("forum.create.page", { id: __props.topic.id })
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Create `);
                  } else {
                    return [
                      createTextVNode(" Create ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else if (_ctx.$page.props.auth.user.staff != "1" && __props.topic.is_staff_only_posting == "0") {
              _push2(ssrRenderComponent(_component_Link, {
                class: "button is-info is-rounded is-fullwidth",
                href: _ctx.route("forum.create.page", { id: __props.topic.id })
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Create `);
                  } else {
                    return [
                      createTextVNode(" Create ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><aside class="menu"${_scopeId}><p class="menu-label"${_scopeId}>Official</p><ul class="menu-list"${_scopeId}><!--[-->`);
            ssrRenderList(__props.section_one, (Official) => {
              _push2(`<li${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Link, {
                href: _ctx.route("forum.page", { id: Official.id })
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    if (Official.is_staff_only_posting == "1") {
                      _push3(`<i class="fas fa-lock"${_scopeId2}></i>`);
                    } else {
                      _push3(`<!---->`);
                    }
                    _push3(` ${ssrInterpolate(Official.name)}`);
                  } else {
                    return [
                      Official.is_staff_only_posting == "1" ? (openBlock(), createBlock("i", {
                        key: 0,
                        class: "fas fa-lock"
                      })) : createCommentVNode("", true),
                      createTextVNode(" " + toDisplayString(Official.name), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</li>`);
            });
            _push2(`<!--]--><p class="menu-label"${_scopeId}>Community</p><!--[-->`);
            ssrRenderList(__props.section_two, (Community) => {
              _push2(`<li${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Link, {
                href: _ctx.route("forum.page", { id: Community.id })
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(Community.name)}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(Community.name), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</li>`);
            });
            _push2(`<!--]--><p class="menu-label"${_scopeId}>Serious</p><!--[-->`);
            ssrRenderList(__props.section_three, (Serious) => {
              _push2(`<li${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Link, {
                href: _ctx.route("forum.page", { id: Serious.id })
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(Serious.name)}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(Serious.name), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</li>`);
            });
            _push2(`<!--]--></ul></aside></span></div><div class="column is-9"${_scopeId}><span slot="primary"${_scopeId}><div class="box"${_scopeId}><!--[-->`);
            ssrRenderList(__props.posts.data, (post) => {
              _push2(`<article class="media is-align-items-center"${_scopeId}><div class="media-left"${_scopeId}><figure class="headshot image is-64x64"${_scopeId}><img class="is-rounded" src="/props/aeo_headshot.png" alt="Avatar Render"${_scopeId}></figure></div><div class="media-content"${_scopeId}><div class="content"${_scopeId}><div class="is-size-6"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Link, {
                class: "is-link",
                href: ""
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(post.name)}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(post.name), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</div> <small${_scopeId}>Made by `);
              _push2(ssrRenderComponent(_component_Link, {
                href: _ctx.route("user.profile", { username: post.username }),
                class: ""
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(post.username)}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(post.username), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`, <span class="has-text-weight-semibold tooltip is-tooltip-top" data-tooltip="Thu Oct 08 2020 03:58:33 GMT-0400"${_scopeId}>a year ago</span> <br${_scopeId}> Last reply by `);
              _push2(ssrRenderComponent(_component_Link, {
                href: _ctx.route("user.profile", { username: post.username })
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`F0X`);
                  } else {
                    return [
                      createTextVNode("F0X")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`, <span class="has-text-weight-semibold tooltip is-tooltip-top" data-tooltip="Thu Oct 08 2020 04:06:53 GMT-0400"${_scopeId}>a year ago</span></small></div></div></article>`);
            });
            _push2(`<!--]--></div></span></div></div></section></div>`);
          } else {
            return [
              createVNode("div", { class: "container" }, [
                createVNode("section", { class: "section" }, [
                  createVNode("div", { class: "columns" }, [
                    createVNode("div", { class: "column is-3" }, [
                      createVNode("span", { slot: "secondary" }, [
                        createVNode("div", { class: "title" }, toDisplayString(__props.topic.name), 1),
                        createVNode("div", { class: "subtitle is-6 has-text-grey-light" }, toDisplayString(__props.topic.description), 1),
                        createVNode("div", { class: "buttons" }, [
                          _ctx.$page.props.auth.user.staff >= "1" && __props.topic.is_staff_only_posting == "1" ? (openBlock(), createBlock(_component_Link, {
                            key: 0,
                            class: "button is-info is-rounded is-fullwidth",
                            href: _ctx.route("forum.create.page", { id: __props.topic.id })
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Create ")
                            ]),
                            _: 1
                          }, 8, ["href"])) : _ctx.$page.props.auth.user.staff != "1" && __props.topic.is_staff_only_posting == "0" ? (openBlock(), createBlock(_component_Link, {
                            key: 1,
                            class: "button is-info is-rounded is-fullwidth",
                            href: _ctx.route("forum.create.page", { id: __props.topic.id })
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Create ")
                            ]),
                            _: 1
                          }, 8, ["href"])) : createCommentVNode("", true)
                        ]),
                        createVNode("aside", { class: "menu" }, [
                          createVNode("p", { class: "menu-label" }, "Official"),
                          createVNode("ul", { class: "menu-list" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(__props.section_one, (Official) => {
                              return openBlock(), createBlock("li", null, [
                                createVNode(_component_Link, {
                                  href: _ctx.route("forum.page", { id: Official.id })
                                }, {
                                  default: withCtx(() => [
                                    Official.is_staff_only_posting == "1" ? (openBlock(), createBlock("i", {
                                      key: 0,
                                      class: "fas fa-lock"
                                    })) : createCommentVNode("", true),
                                    createTextVNode(" " + toDisplayString(Official.name), 1)
                                  ]),
                                  _: 2
                                }, 1032, ["href"])
                              ]);
                            }), 256)),
                            createVNode("p", { class: "menu-label" }, "Community"),
                            (openBlock(true), createBlock(Fragment, null, renderList(__props.section_two, (Community) => {
                              return openBlock(), createBlock("li", null, [
                                createVNode(_component_Link, {
                                  href: _ctx.route("forum.page", { id: Community.id })
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(Community.name), 1)
                                  ]),
                                  _: 2
                                }, 1032, ["href"])
                              ]);
                            }), 256)),
                            createVNode("p", { class: "menu-label" }, "Serious"),
                            (openBlock(true), createBlock(Fragment, null, renderList(__props.section_three, (Serious) => {
                              return openBlock(), createBlock("li", null, [
                                createVNode(_component_Link, {
                                  href: _ctx.route("forum.page", { id: Serious.id })
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(Serious.name), 1)
                                  ]),
                                  _: 2
                                }, 1032, ["href"])
                              ]);
                            }), 256))
                          ])
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "column is-9" }, [
                      createVNode("span", { slot: "primary" }, [
                        createVNode("div", { class: "box" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.posts.data, (post) => {
                            return openBlock(), createBlock("article", { class: "media is-align-items-center" }, [
                              createVNode("div", { class: "media-left" }, [
                                createVNode("figure", { class: "headshot image is-64x64" }, [
                                  createVNode("img", {
                                    class: "is-rounded",
                                    src: "/props/aeo_headshot.png",
                                    alt: "Avatar Render"
                                  })
                                ])
                              ]),
                              createVNode("div", { class: "media-content" }, [
                                createVNode("div", { class: "content" }, [
                                  createVNode("div", { class: "is-size-6" }, [
                                    createVNode(_component_Link, {
                                      class: "is-link",
                                      href: ""
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(post.name), 1)
                                      ]),
                                      _: 2
                                    }, 1024)
                                  ]),
                                  createTextVNode(),
                                  createVNode("small", null, [
                                    createTextVNode("Made by "),
                                    createVNode(_component_Link, {
                                      href: _ctx.route("user.profile", { username: post.username }),
                                      class: ""
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(post.username), 1)
                                      ]),
                                      _: 2
                                    }, 1032, ["href"]),
                                    createTextVNode(", "),
                                    createVNode("span", {
                                      class: "has-text-weight-semibold tooltip is-tooltip-top",
                                      "data-tooltip": "Thu Oct 08 2020 03:58:33 GMT-0400"
                                    }, "a year ago"),
                                    createTextVNode(),
                                    createVNode("br"),
                                    createTextVNode(" Last reply by "),
                                    createVNode(_component_Link, {
                                      href: _ctx.route("user.profile", { username: post.username })
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("F0X")
                                      ]),
                                      _: 2
                                    }, 1032, ["href"]),
                                    createTextVNode(", "),
                                    createVNode("span", {
                                      class: "has-text-weight-semibold tooltip is-tooltip-top",
                                      "data-tooltip": "Thu Oct 08 2020 04:06:53 GMT-0400"
                                    }, "a year ago")
                                  ])
                                ])
                              ])
                            ]);
                          }), 256))
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Forum/Index.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const __vite_glob_0_6 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main$9
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$8 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(` soon `);
}
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Forum/Reply.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const Reply = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["ssrRender", _sfc_ssrRender]]);
const __vite_glob_0_7 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Reply
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$7 = {
  __name: "DeleteUserForm",
  __ssrInlineRender: true,
  setup(__props) {
    const confirmingUserDeletion = ref(false);
    ref(null);
    const form = useForm({
      password: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><button class="button is-danger">Delete Account</button><div class="${ssrRenderClass([{ "is-active": confirmingUserDeletion.value }, "modal"])}"><form><div class="modal-background"></div><div class="modal-card"><header class="modal-card-head"><p class="modal-card-title">Are you sure you want to delete your account?</p><button class="delete"></button></header><section class="modal-card-body"> Once your account is deleted, all of its resources and data will be permanently deleted. Please enter your password to confirm you would like to permanently delete your account. <div class="field"><div class="control"><input id="password"${ssrRenderAttr("value", unref(form).password)} type="password" class="input is-danger" placeholder="Password"></div></div><div${ssrRenderAttr("message", unref(form).errors.password)} class="mt-2"></div></section><footer class="modal-card-foot"><button class="button">Cancel</button><button class="button is-danger"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""}> Close Account </button></footer></div></form></div><!--]-->`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Settings/Partials/DeleteUserForm.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __vite_glob_0_9 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main$7
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$6 = {
  __name: "UpdatePasswordForm",
  __ssrInlineRender: true,
  setup(__props) {
    ref(null);
    ref(null);
    const form = useForm({
      current_password: "",
      password: "",
      password_confirmation: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(_attrs)}><form class="mt-6 space-y-6"><div><label for="current_password" value="Current Password"></label><input id="current_password"${ssrRenderAttr("value", unref(form).current_password)} type="password" class="mt-1 block w-full" autocomplete="current-password"><div${ssrRenderAttr("message", unref(form).errors.current_password)} class="mt-2"></div></div><div><label for="password" value="New Password"></label><input id="password"${ssrRenderAttr("value", unref(form).password)} type="password" class="mt-1 block w-full" autocomplete="new-password"><input${ssrRenderAttr("message", unref(form).errors.password)} class="mt-2"></div><div><label for="password_confirmation" value="Confirm Password"></label><input id="password_confirmation"${ssrRenderAttr("value", unref(form).password_confirmation)} type="password" class="mt-1 block w-full" autocomplete="new-password"><div${ssrRenderAttr("message", unref(form).errors.password_confirmation)} class="mt-2"></div></div><div class="flex items-center gap-4"><button${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""}>Save</button></div></form></section>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Settings/Partials/UpdatePasswordForm.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __vite_glob_0_10 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main$6
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$5 = {
  __name: "UpdateProfileInformationForm",
  __ssrInlineRender: true,
  props: {
    mustVerifyEmail: Boolean,
    status: String
  },
  setup(__props) {
    const props = __props;
    const user = usePage().props.value.auth.user;
    const form = useForm({
      name: user.name,
      email: user.email
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(_attrs)}><form class="mt-6 space-y-6"><div><label for="name" value="Name"></label><input id="name" type="text" class="mt-1 block w-full"${ssrRenderAttr("value", unref(form).name)} required autofocus autocomplete="name"><div class="mt-2"${ssrRenderAttr("message", unref(form).errors.name)}></div></div><div><label for="email" value="Email"></label><input id="email" type="email" class="mt-1 block w-full"${ssrRenderAttr("value", unref(form).email)} required autocomplete="email"><div class="mt-2"${ssrRenderAttr("message", unref(form).errors.email)}></div></div>`);
      if (props.mustVerifyEmail && unref(user).email_verified_at === null) {
        _push(`<div><p class="text-sm mt-2 text-gray-800"> Your email address is unverified. `);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("verification.send"),
          method: "post",
          as: "button",
          class: "underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Click here to re-send the verification email. `);
            } else {
              return [
                createTextVNode(" Click here to re-send the verification email. ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</p><div style="${ssrRenderStyle(props.status === "verification-link-sent" ? null : { display: "none" })}" class="mt-2 font-medium text-sm text-green-600"> A new verification link has been sent to your email address. </div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="flex items-center gap-4"><button${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""}>Save</button></div></form></section>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Settings/Partials/UpdateProfileInformationForm.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __vite_glob_0_11 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main$5
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$4 = {
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    mustVerifyEmail: Boolean,
    status: String
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$h, mergeProps({ title: "Settings" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container"${_scopeId}><section class="section"${_scopeId}><div class="columns"${_scopeId}><div class="column is-3"${_scopeId}><span slot="secondary"${_scopeId}><div class="title"${_scopeId}>Settings</div><div class="subtitle is-6 has-text-grey-light"${_scopeId}>Manage your account here</div><aside class="menu"${_scopeId}><p class="menu-label"${_scopeId}>The Kitchen Sink</p><ul class="menu-list"${_scopeId}><li${_scopeId}><a class="is-active"${_scopeId}>Overview</a></li></ul></aside></span></div><div class="column is-9"${_scopeId}><span slot="primary"${_scopeId}><div class="title"${_scopeId}>Profile Information</div><div class="subtitle is-6 has-text-grey-light mb-3"${_scopeId}>Crucial user variables</div><div class="box"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$5, {
              "must-verify-email": __props.mustVerifyEmail,
              status: __props.status,
              class: "max-w-xl"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="box"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$6, { class: "max-w-xl" }, null, _parent2, _scopeId));
            _push2(`</div><div class="box"${_scopeId}><label class="label"${_scopeId}>Account Deletion</label><div class="field help has-text-grey-light"${_scopeId}>Click the button to delete your account. You cannot recover your account unless you contact a staff member.</div>`);
            _push2(ssrRenderComponent(_sfc_main$7, { class: "max-w-xl" }, null, _parent2, _scopeId));
            _push2(`</div></span></div></div></section></div>`);
          } else {
            return [
              createVNode("div", { class: "container" }, [
                createVNode("section", { class: "section" }, [
                  createVNode("div", { class: "columns" }, [
                    createVNode("div", { class: "column is-3" }, [
                      createVNode("span", { slot: "secondary" }, [
                        createVNode("div", { class: "title" }, "Settings"),
                        createVNode("div", { class: "subtitle is-6 has-text-grey-light" }, "Manage your account here"),
                        createVNode("aside", { class: "menu" }, [
                          createVNode("p", { class: "menu-label" }, "The Kitchen Sink"),
                          createVNode("ul", { class: "menu-list" }, [
                            createVNode("li", null, [
                              createVNode("a", { class: "is-active" }, "Overview")
                            ])
                          ])
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "column is-9" }, [
                      createVNode("span", { slot: "primary" }, [
                        createVNode("div", { class: "title" }, "Profile Information"),
                        createVNode("div", { class: "subtitle is-6 has-text-grey-light mb-3" }, "Crucial user variables"),
                        createVNode("div", { class: "box" }, [
                          createVNode(_sfc_main$5, {
                            "must-verify-email": __props.mustVerifyEmail,
                            status: __props.status,
                            class: "max-w-xl"
                          }, null, 8, ["must-verify-email", "status"])
                        ]),
                        createVNode("div", { class: "box" }, [
                          createVNode(_sfc_main$6, { class: "max-w-xl" })
                        ]),
                        createVNode("div", { class: "box" }, [
                          createVNode("label", { class: "label" }, "Account Deletion"),
                          createVNode("div", { class: "field help has-text-grey-light" }, "Click the button to delete your account. You cannot recover your account unless you contact a staff member."),
                          createVNode(_sfc_main$7, { class: "max-w-xl" })
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Settings/Edit.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __vite_glob_0_8 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main$4
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$3 = {
  __name: "Index",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$h, mergeProps({ title: "Store" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container"${_scopeId}><section class="section"${_scopeId}><div class="columns"${_scopeId}><div class="column is-3"${_scopeId}><span slot="secondary"${_scopeId}><div class="title"${_scopeId}>Store</div><div class="subtitle is-6 has-text-grey-light"${_scopeId}>Skin through numerous virtual items to create your own perfect &amp; unique identity</div><aside class="menu"${_scopeId}><p class="menu-label"${_scopeId}>Basic</p><ul class="menu-list"${_scopeId}><li${_scopeId}><a href="https://vistora.xyz/forum/1"${_scopeId}> Hats </a></li><li${_scopeId}><a href="https://vistora.xyz/forum/1"${_scopeId}> Faces </a></li><li${_scopeId}><a href="https://vistora.xyz/forum/1"${_scopeId}> Gears </a></li><li${_scopeId}><a href="https://vistora.xyz/forum/1"${_scopeId}> Shirts </a></li><li${_scopeId}><a href="https://vistora.xyz/forum/1"${_scopeId}> Pants </a></li><p class="menu-label"${_scopeId}>Extra</p><li${_scopeId}><a href="https://vistora.xyz/forum/1"${_scopeId}> Heads </a></li><li${_scopeId}><a href="https://vistora.xyz/forum/1"${_scopeId}> Accessories </a></li><li${_scopeId}><a href="https://vistora.xyz/forum/1"${_scopeId}> Crates </a></li></ul></aside></span></div></div></section></div>`);
          } else {
            return [
              createVNode("div", { class: "container" }, [
                createVNode("section", { class: "section" }, [
                  createVNode("div", { class: "columns" }, [
                    createVNode("div", { class: "column is-3" }, [
                      createVNode("span", { slot: "secondary" }, [
                        createVNode("div", { class: "title" }, "Store"),
                        createVNode("div", { class: "subtitle is-6 has-text-grey-light" }, "Skin through numerous virtual items to create your own perfect & unique identity"),
                        createVNode("aside", { class: "menu" }, [
                          createVNode("p", { class: "menu-label" }, "Basic"),
                          createVNode("ul", { class: "menu-list" }, [
                            createVNode("li", null, [
                              createVNode("a", { href: "https://vistora.xyz/forum/1" }, " Hats ")
                            ]),
                            createVNode("li", null, [
                              createVNode("a", { href: "https://vistora.xyz/forum/1" }, " Faces ")
                            ]),
                            createVNode("li", null, [
                              createVNode("a", { href: "https://vistora.xyz/forum/1" }, " Gears ")
                            ]),
                            createVNode("li", null, [
                              createVNode("a", { href: "https://vistora.xyz/forum/1" }, " Shirts ")
                            ]),
                            createVNode("li", null, [
                              createVNode("a", { href: "https://vistora.xyz/forum/1" }, " Pants ")
                            ]),
                            createVNode("p", { class: "menu-label" }, "Extra"),
                            createVNode("li", null, [
                              createVNode("a", { href: "https://vistora.xyz/forum/1" }, " Heads ")
                            ]),
                            createVNode("li", null, [
                              createVNode("a", { href: "https://vistora.xyz/forum/1" }, " Accessories ")
                            ]),
                            createVNode("li", null, [
                              createVNode("a", { href: "https://vistora.xyz/forum/1" }, " Crates ")
                            ])
                          ])
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Store/Index.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __vite_glob_0_12 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main$3
}, Symbol.toStringTag, { value: "Module" }));
const __default__$1 = {
  props: {
    users: Object
  },
  methods: {
    getUserList(page) {
      var vm = this;
      if (page == void 0) {
        var pageUrl = "/user/discover";
      } else {
        var pageUrl = "/user/discover/?page=" + page;
      }
      axios.get(pageUrl).then(function(response) {
        if (response.data.hasOwnProperty("success")) {
          vm.users = response.data.users;
          vm.tags = response.data.users.data;
        }
      }).catch(function(error) {
        console.log(error);
      });
    }
  }
};
const _sfc_main$2 = /* @__PURE__ */ Object.assign(__default__$1, {
  __name: "Index",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Link = resolveComponent("Link");
      const _component_Aeopage = resolveComponent("Aeopage");
      _push(ssrRenderComponent(_sfc_main$h, mergeProps({ title: "Discover" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container"${_scopeId}><section class="section"${_scopeId}><div class="columns"${_scopeId}><div class="column is-3"${_scopeId}><div class="title"${_scopeId}>Discover</div><div class="subtitle is-6 has-text-grey-light"${_scopeId}>Find new friends among thousands of users</div><aside class="menu"${_scopeId}><p class="menu-label"${_scopeId}>Navigate</p><ul class="menu-list"${_scopeId}><li${_scopeId}><a class="is-active"${_scopeId}>All</a></li></ul></aside></div><div class="column is-9"${_scopeId}><nav class="level is-mobile"${_scopeId}><div class="level-left"${_scopeId}><div class="level-item"${_scopeId}><div class="has-text-weight-semibold"${_scopeId}>Users</div></div></div><div class="level-right"${_scopeId}><form${_scopeId}><fieldset${_scopeId}><div class="field has-addons mb-0"${_scopeId}><p class="control"${_scopeId}><input class="input is-small" type="text" placeholder="Search"${_scopeId}></p><p class="control"${_scopeId}><button class="button is-info is-small"${_scopeId}>Search</button></p></div></fieldset></form></div></nav><div class="columns is-multiline"${_scopeId}><!--[-->`);
            ssrRenderList(__props.users.data, (user) => {
              _push2(`<div class="column is-6"${_scopeId}><div class="box hover-shadow-slow"${_scopeId}><article class="media is-align-items-center"${_scopeId}><div class="media-left"${_scopeId}><figure class="headshot image is-64x64"${_scopeId}><img class="is-rounded" src="/props/aeo_headshot.png" alt="Avatar Render"${_scopeId}></figure></div><div class="media-content"${_scopeId}><div class="content"${_scopeId}><div class="is-size-5"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Link, {
                class: "is-link",
                href: _ctx.route("user.profile", { username: user.name })
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<span class="has-text-truncate"${_scopeId2}>${ssrInterpolate(user.name)}</span>`);
                  } else {
                    return [
                      createVNode("span", { class: "has-text-truncate" }, toDisplayString(user.name), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</div><div class="is-size-7 has-text-grey-light"${_scopeId}><span class="has-text-truncate"${_scopeId}>${ssrInterpolate(user.status)}</span></div></div></div>`);
              if (user.staff == "1") {
                _push2(`<div class="media-right is-hidden-mobile"${_scopeId}><span class="tag is-info tooltip has-tooltip-top" data-tooltip="This user is an official Vistora staff member"${_scopeId}>Admin</span></div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</article></div></div>`);
            });
            _push2(`<!--]--></div></div>`);
            _push2(ssrRenderComponent(_component_Aeopage, {
              pagedata: __props.users,
              onPageClicked: _ctx.getUserList
            }, null, _parent2, _scopeId));
            _push2(`</div></section></div>`);
          } else {
            return [
              createVNode("div", { class: "container" }, [
                createVNode("section", { class: "section" }, [
                  createVNode("div", { class: "columns" }, [
                    createVNode("div", { class: "column is-3" }, [
                      createVNode("div", { class: "title" }, "Discover"),
                      createVNode("div", { class: "subtitle is-6 has-text-grey-light" }, "Find new friends among thousands of users"),
                      createVNode("aside", { class: "menu" }, [
                        createVNode("p", { class: "menu-label" }, "Navigate"),
                        createVNode("ul", { class: "menu-list" }, [
                          createVNode("li", null, [
                            createVNode("a", { class: "is-active" }, "All")
                          ])
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "column is-9" }, [
                      createVNode("nav", { class: "level is-mobile" }, [
                        createVNode("div", { class: "level-left" }, [
                          createVNode("div", { class: "level-item" }, [
                            createVNode("div", { class: "has-text-weight-semibold" }, "Users")
                          ])
                        ]),
                        createVNode("div", { class: "level-right" }, [
                          createVNode("form", null, [
                            createVNode("fieldset", null, [
                              createVNode("div", { class: "field has-addons mb-0" }, [
                                createVNode("p", { class: "control" }, [
                                  createVNode("input", {
                                    class: "input is-small",
                                    type: "text",
                                    placeholder: "Search"
                                  })
                                ]),
                                createVNode("p", { class: "control" }, [
                                  createVNode("button", { class: "button is-info is-small" }, "Search")
                                ])
                              ])
                            ])
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "columns is-multiline" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.users.data, (user) => {
                          return openBlock(), createBlock("div", {
                            class: "column is-6",
                            key: user.id
                          }, [
                            createVNode("div", { class: "box hover-shadow-slow" }, [
                              createVNode("article", { class: "media is-align-items-center" }, [
                                createVNode("div", { class: "media-left" }, [
                                  createVNode("figure", { class: "headshot image is-64x64" }, [
                                    createVNode("img", {
                                      class: "is-rounded",
                                      src: "/props/aeo_headshot.png",
                                      alt: "Avatar Render"
                                    })
                                  ])
                                ]),
                                createVNode("div", { class: "media-content" }, [
                                  createVNode("div", { class: "content" }, [
                                    createVNode("div", { class: "is-size-5" }, [
                                      createVNode(_component_Link, {
                                        class: "is-link",
                                        href: _ctx.route("user.profile", { username: user.name })
                                      }, {
                                        default: withCtx(() => [
                                          createVNode("span", { class: "has-text-truncate" }, toDisplayString(user.name), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["href"])
                                    ]),
                                    createVNode("div", { class: "is-size-7 has-text-grey-light" }, [
                                      createVNode("span", { class: "has-text-truncate" }, toDisplayString(user.status), 1)
                                    ])
                                  ])
                                ]),
                                user.staff == "1" ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "media-right is-hidden-mobile"
                                }, [
                                  createVNode("span", {
                                    class: "tag is-info tooltip has-tooltip-top",
                                    "data-tooltip": "This user is an official Vistora staff member"
                                  }, "Admin")
                                ])) : createCommentVNode("", true)
                              ])
                            ])
                          ]);
                        }), 128))
                      ])
                    ]),
                    createVNode(_component_Aeopage, {
                      pagedata: __props.users,
                      onPageClicked: _ctx.getUserList
                    }, null, 8, ["pagedata", "onPageClicked"])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Users/Index.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __vite_glob_0_13 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main$2
}, Symbol.toStringTag, { value: "Module" }));
const __default__ = {
  props: {
    user: Object
  }
};
const _sfc_main$1 = /* @__PURE__ */ Object.assign(__default__, {
  __name: "Profile",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$h, mergeProps({ title: "Aeo" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container"${_scopeId}><section class="section"${_scopeId}><div class="columns is-centered"${_scopeId}><div class="column is-3"${_scopeId}><div class="box has-text-centered mb-1"${_scopeId}><img src="/props/aeo.png" alt="Avatar Render"${_scopeId}><hr${_scopeId}><div class="is-size-7 has-text-grey-light is-whitespace"${_scopeId}>${ssrInterpolate(__props.user.bio)}</div></div><span slot="buttons"${_scopeId}><div class="block mt-3 mb-2"${_scopeId}><div class="buttons"${_scopeId}><button type="submit" class="button is-info is-fullwidth"${_scopeId}>Follow</button><button class="button is-info is-fullwidth"${_scopeId}>Chat</button><a href="#" class="button is-info is-fullwidth"${_scopeId}>Trade</a></div></div></span><div class="block"${_scopeId}><span slot="statistics"${_scopeId}><div class="is-size-5 has-text-weight-semibold mb-1"${_scopeId}>Statistics</div><div class="box"${_scopeId}><div${_scopeId}><span class="has-text-weight-semibold"${_scopeId}>Posts</span><span class="is-pulled-right"${_scopeId}>288</span></div><div${_scopeId}><span class="has-text-weight-semibold"${_scopeId}>Views</span><span class="is-pulled-right"${_scopeId}>${ssrInterpolate(__props.user.views)}</span></div><div${_scopeId}><span class="has-text-weight-semibold"${_scopeId}>Followers</span><span class="is-pulled-right"${_scopeId}>22</span></div><div${_scopeId}><span class="has-text-weight-semibold"${_scopeId}>Following</span><span class="is-pulled-right"${_scopeId}>13</span></div></div></span></div></div><div class="column is-6"${_scopeId}><div class="is-size-5 has-text-weight-semibold mb-2"${_scopeId}>${ssrInterpolate(__props.user.name)}&#39;s Profile <span class="tags is-pulled-right"${_scopeId}><span class="tag is-danger tooltip has-tooltip-top is-rounded" data-tooltip="4 minutes ago"${_scopeId}>Offline</span></span></div><div class="box"${_scopeId}><div class="menu-label mb-1"${_scopeId}>Status</div> ${ssrInterpolate(__props.user.status)} <div class="menu-label mt-3 mb-1"${_scopeId}>Creation Date</div><span class="tooltip has-tooltip-top" data-tooltip="2 years, 1 month ago"${_scopeId}>November 20, 2020</span><div class="menu-label mt-3 mb-1"${_scopeId}>Last Seen</div><span class="tooltip has-tooltip-top" data-tooltip="4 minutes ago"${_scopeId}>January 11, 2023</span></div></div></div></section></div>`);
          } else {
            return [
              createVNode("div", { class: "container" }, [
                createVNode("section", { class: "section" }, [
                  createVNode("div", { class: "columns is-centered" }, [
                    createVNode("div", { class: "column is-3" }, [
                      createVNode("div", { class: "box has-text-centered mb-1" }, [
                        createVNode("img", {
                          src: "/props/aeo.png",
                          alt: "Avatar Render"
                        }),
                        createVNode("hr"),
                        createVNode("div", { class: "is-size-7 has-text-grey-light is-whitespace" }, toDisplayString(__props.user.bio), 1)
                      ]),
                      createVNode("span", { slot: "buttons" }, [
                        createVNode("div", { class: "block mt-3 mb-2" }, [
                          createVNode("div", { class: "buttons" }, [
                            createVNode("button", {
                              type: "submit",
                              class: "button is-info is-fullwidth"
                            }, "Follow"),
                            createVNode("button", { class: "button is-info is-fullwidth" }, "Chat"),
                            createVNode("a", {
                              href: "#",
                              class: "button is-info is-fullwidth"
                            }, "Trade")
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "block" }, [
                        createVNode("span", { slot: "statistics" }, [
                          createVNode("div", { class: "is-size-5 has-text-weight-semibold mb-1" }, "Statistics"),
                          createVNode("div", { class: "box" }, [
                            createVNode("div", null, [
                              createVNode("span", { class: "has-text-weight-semibold" }, "Posts"),
                              createVNode("span", { class: "is-pulled-right" }, "288")
                            ]),
                            createVNode("div", null, [
                              createVNode("span", { class: "has-text-weight-semibold" }, "Views"),
                              createVNode("span", { class: "is-pulled-right" }, toDisplayString(__props.user.views), 1)
                            ]),
                            createVNode("div", null, [
                              createVNode("span", { class: "has-text-weight-semibold" }, "Followers"),
                              createVNode("span", { class: "is-pulled-right" }, "22")
                            ]),
                            createVNode("div", null, [
                              createVNode("span", { class: "has-text-weight-semibold" }, "Following"),
                              createVNode("span", { class: "is-pulled-right" }, "13")
                            ])
                          ])
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "column is-6" }, [
                      createVNode("div", { class: "is-size-5 has-text-weight-semibold mb-2" }, [
                        createTextVNode(toDisplayString(__props.user.name) + "'s Profile ", 1),
                        createVNode("span", { class: "tags is-pulled-right" }, [
                          createVNode("span", {
                            class: "tag is-danger tooltip has-tooltip-top is-rounded",
                            "data-tooltip": "4 minutes ago"
                          }, "Offline")
                        ])
                      ]),
                      createVNode("div", { class: "box" }, [
                        createVNode("div", { class: "menu-label mb-1" }, "Status"),
                        createTextVNode(" " + toDisplayString(__props.user.status) + " ", 1),
                        createVNode("div", { class: "menu-label mt-3 mb-1" }, "Creation Date"),
                        createVNode("span", {
                          class: "tooltip has-tooltip-top",
                          "data-tooltip": "2 years, 1 month ago"
                        }, "November 20, 2020"),
                        createVNode("div", { class: "menu-label mt-3 mb-1" }, "Last Seen"),
                        createVNode("span", {
                          class: "tooltip has-tooltip-top",
                          "data-tooltip": "4 minutes ago"
                        }, "January 11, 2023")
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Users/Profile.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __vite_glob_0_14 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main$1
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main = {
  __name: "Welcome",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$h, mergeProps({ title: "Welcome" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<section class="index-hero hero is-fullheight"${_scopeId}><div class="hero-body"${_scopeId}><div class="container"${_scopeId}><div class="columns is-centered"${_scopeId}><div class="column is-12 has-text-pulled-left"${_scopeId}><div class="title is-1 has-text-weight-normal mb-2"${_scopeId}> Welcome to Vistora </div><div class="title is-5 has-text-grey-light has-font-weight-light mb-3"${_scopeId}> Join thousands of users who are creating, innovating &amp; interacting </div>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("auth.register.page")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<button class="button is-info"${_scopeId2}> Register </button>`);
                } else {
                  return [
                    createVNode("button", { class: "button is-info" }, " Register ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div></div></div></section>`);
          } else {
            return [
              createVNode("section", { class: "index-hero hero is-fullheight" }, [
                createVNode("div", { class: "hero-body" }, [
                  createVNode("div", { class: "container" }, [
                    createVNode("div", { class: "columns is-centered" }, [
                      createVNode("div", { class: "column is-12 has-text-pulled-left" }, [
                        createVNode("div", { class: "title is-1 has-text-weight-normal mb-2" }, " Welcome to Vistora "),
                        createVNode("div", { class: "title is-5 has-text-grey-light has-font-weight-light mb-3" }, " Join thousands of users who are creating, innovating & interacting "),
                        createVNode(unref(Link), {
                          href: _ctx.route("auth.register.page")
                        }, {
                          default: withCtx(() => [
                            createVNode("button", { class: "button is-info" }, " Register ")
                          ]),
                          _: 1
                        }, 8, ["href"])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Welcome.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __vite_glob_0_15 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _sfc_main
}, Symbol.toStringTag, { value: "Module" }));
function t(t4, r2) {
  for (var n2 = 0; n2 < r2.length; n2++) {
    var e2 = r2[n2];
    e2.enumerable = e2.enumerable || false, e2.configurable = true, "value" in e2 && (e2.writable = true), Object.defineProperty(t4, e2.key, e2);
  }
}
function r(r2, n2, e2) {
  return n2 && t(r2.prototype, n2), e2 && t(r2, e2), Object.defineProperty(r2, "prototype", { writable: false }), r2;
}
function n() {
  return n = Object.assign ? Object.assign.bind() : function(t4) {
    for (var r2 = 1; r2 < arguments.length; r2++) {
      var n2 = arguments[r2];
      for (var e2 in n2)
        Object.prototype.hasOwnProperty.call(n2, e2) && (t4[e2] = n2[e2]);
    }
    return t4;
  }, n.apply(this, arguments);
}
function e(t4) {
  return e = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t5) {
    return t5.__proto__ || Object.getPrototypeOf(t5);
  }, e(t4);
}
function o(t4, r2) {
  return o = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t5, r3) {
    return t5.__proto__ = r3, t5;
  }, o(t4, r2);
}
function i() {
  if ("undefined" == typeof Reflect || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if ("function" == typeof Proxy)
    return true;
  try {
    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    })), true;
  } catch (t4) {
    return false;
  }
}
function u(t4, r2, n2) {
  return u = i() ? Reflect.construct.bind() : function(t5, r3, n3) {
    var e2 = [null];
    e2.push.apply(e2, r3);
    var i2 = new (Function.bind.apply(t5, e2))();
    return n3 && o(i2, n3.prototype), i2;
  }, u.apply(null, arguments);
}
function f(t4) {
  var r2 = "function" == typeof Map ? /* @__PURE__ */ new Map() : void 0;
  return f = function(t5) {
    if (null === t5 || -1 === Function.toString.call(t5).indexOf("[native code]"))
      return t5;
    if ("function" != typeof t5)
      throw new TypeError("Super expression must either be null or a function");
    if (void 0 !== r2) {
      if (r2.has(t5))
        return r2.get(t5);
      r2.set(t5, n2);
    }
    function n2() {
      return u(t5, arguments, e(this).constructor);
    }
    return n2.prototype = Object.create(t5.prototype, { constructor: { value: n2, enumerable: false, writable: true, configurable: true } }), o(n2, t5);
  }, f(t4);
}
var a = String.prototype.replace, c = /%20/g, l = { default: "RFC3986", formatters: { RFC1738: function(t4) {
  return a.call(t4, c, "+");
}, RFC3986: function(t4) {
  return String(t4);
} }, RFC1738: "RFC1738", RFC3986: "RFC3986" }, s = Object.prototype.hasOwnProperty, v = Array.isArray, p = function() {
  for (var t4 = [], r2 = 0; r2 < 256; ++r2)
    t4.push("%" + ((r2 < 16 ? "0" : "") + r2.toString(16)).toUpperCase());
  return t4;
}(), y = function(t4, r2) {
  for (var n2 = r2 && r2.plainObjects ? /* @__PURE__ */ Object.create(null) : {}, e2 = 0; e2 < t4.length; ++e2)
    void 0 !== t4[e2] && (n2[e2] = t4[e2]);
  return n2;
}, d = { arrayToObject: y, assign: function(t4, r2) {
  return Object.keys(r2).reduce(function(t5, n2) {
    return t5[n2] = r2[n2], t5;
  }, t4);
}, combine: function(t4, r2) {
  return [].concat(t4, r2);
}, compact: function(t4) {
  for (var r2 = [{ obj: { o: t4 }, prop: "o" }], n2 = [], e2 = 0; e2 < r2.length; ++e2)
    for (var o2 = r2[e2], i2 = o2.obj[o2.prop], u2 = Object.keys(i2), f2 = 0; f2 < u2.length; ++f2) {
      var a2 = u2[f2], c2 = i2[a2];
      "object" == typeof c2 && null !== c2 && -1 === n2.indexOf(c2) && (r2.push({ obj: i2, prop: a2 }), n2.push(c2));
    }
  return function(t5) {
    for (; t5.length > 1; ) {
      var r3 = t5.pop(), n3 = r3.obj[r3.prop];
      if (v(n3)) {
        for (var e3 = [], o3 = 0; o3 < n3.length; ++o3)
          void 0 !== n3[o3] && e3.push(n3[o3]);
        r3.obj[r3.prop] = e3;
      }
    }
  }(r2), t4;
}, decode: function(t4, r2, n2) {
  var e2 = t4.replace(/\+/g, " ");
  if ("iso-8859-1" === n2)
    return e2.replace(/%[0-9a-f]{2}/gi, unescape);
  try {
    return decodeURIComponent(e2);
  } catch (t5) {
    return e2;
  }
}, encode: function(t4, r2, n2, e2, o2) {
  if (0 === t4.length)
    return t4;
  var i2 = t4;
  if ("symbol" == typeof t4 ? i2 = Symbol.prototype.toString.call(t4) : "string" != typeof t4 && (i2 = String(t4)), "iso-8859-1" === n2)
    return escape(i2).replace(/%u[0-9a-f]{4}/gi, function(t5) {
      return "%26%23" + parseInt(t5.slice(2), 16) + "%3B";
    });
  for (var u2 = "", f2 = 0; f2 < i2.length; ++f2) {
    var a2 = i2.charCodeAt(f2);
    45 === a2 || 46 === a2 || 95 === a2 || 126 === a2 || a2 >= 48 && a2 <= 57 || a2 >= 65 && a2 <= 90 || a2 >= 97 && a2 <= 122 || o2 === l.RFC1738 && (40 === a2 || 41 === a2) ? u2 += i2.charAt(f2) : a2 < 128 ? u2 += p[a2] : a2 < 2048 ? u2 += p[192 | a2 >> 6] + p[128 | 63 & a2] : a2 < 55296 || a2 >= 57344 ? u2 += p[224 | a2 >> 12] + p[128 | a2 >> 6 & 63] + p[128 | 63 & a2] : (a2 = 65536 + ((1023 & a2) << 10 | 1023 & i2.charCodeAt(f2 += 1)), u2 += p[240 | a2 >> 18] + p[128 | a2 >> 12 & 63] + p[128 | a2 >> 6 & 63] + p[128 | 63 & a2]);
  }
  return u2;
}, isBuffer: function(t4) {
  return !(!t4 || "object" != typeof t4 || !(t4.constructor && t4.constructor.isBuffer && t4.constructor.isBuffer(t4)));
}, isRegExp: function(t4) {
  return "[object RegExp]" === Object.prototype.toString.call(t4);
}, maybeMap: function(t4, r2) {
  if (v(t4)) {
    for (var n2 = [], e2 = 0; e2 < t4.length; e2 += 1)
      n2.push(r2(t4[e2]));
    return n2;
  }
  return r2(t4);
}, merge: function t2(r2, n2, e2) {
  if (!n2)
    return r2;
  if ("object" != typeof n2) {
    if (v(r2))
      r2.push(n2);
    else {
      if (!r2 || "object" != typeof r2)
        return [r2, n2];
      (e2 && (e2.plainObjects || e2.allowPrototypes) || !s.call(Object.prototype, n2)) && (r2[n2] = true);
    }
    return r2;
  }
  if (!r2 || "object" != typeof r2)
    return [r2].concat(n2);
  var o2 = r2;
  return v(r2) && !v(n2) && (o2 = y(r2, e2)), v(r2) && v(n2) ? (n2.forEach(function(n3, o3) {
    if (s.call(r2, o3)) {
      var i2 = r2[o3];
      i2 && "object" == typeof i2 && n3 && "object" == typeof n3 ? r2[o3] = t2(i2, n3, e2) : r2.push(n3);
    } else
      r2[o3] = n3;
  }), r2) : Object.keys(n2).reduce(function(r3, o3) {
    var i2 = n2[o3];
    return r3[o3] = s.call(r3, o3) ? t2(r3[o3], i2, e2) : i2, r3;
  }, o2);
} }, b = Object.prototype.hasOwnProperty, h = { brackets: function(t4) {
  return t4 + "[]";
}, comma: "comma", indices: function(t4, r2) {
  return t4 + "[" + r2 + "]";
}, repeat: function(t4) {
  return t4;
} }, m = Array.isArray, g = String.prototype.split, j = Array.prototype.push, w = function(t4, r2) {
  j.apply(t4, m(r2) ? r2 : [r2]);
}, O = Date.prototype.toISOString, E = l.default, R = { addQueryPrefix: false, allowDots: false, charset: "utf-8", charsetSentinel: false, delimiter: "&", encode: true, encoder: d.encode, encodeValuesOnly: false, format: E, formatter: l.formatters[E], indices: false, serializeDate: function(t4) {
  return O.call(t4);
}, skipNulls: false, strictNullHandling: false }, S = function t3(r2, n2, e2, o2, i2, u2, f2, a2, c2, l2, s2, v2, p2, y2) {
  var b2, h2 = r2;
  if ("function" == typeof f2 ? h2 = f2(n2, h2) : h2 instanceof Date ? h2 = l2(h2) : "comma" === e2 && m(h2) && (h2 = d.maybeMap(h2, function(t4) {
    return t4 instanceof Date ? l2(t4) : t4;
  })), null === h2) {
    if (o2)
      return u2 && !p2 ? u2(n2, R.encoder, y2, "key", s2) : n2;
    h2 = "";
  }
  if ("string" == typeof (b2 = h2) || "number" == typeof b2 || "boolean" == typeof b2 || "symbol" == typeof b2 || "bigint" == typeof b2 || d.isBuffer(h2)) {
    if (u2) {
      var j2 = p2 ? n2 : u2(n2, R.encoder, y2, "key", s2);
      if ("comma" === e2 && p2) {
        for (var O2 = g.call(String(h2), ","), E2 = "", S2 = 0; S2 < O2.length; ++S2)
          E2 += (0 === S2 ? "" : ",") + v2(u2(O2[S2], R.encoder, y2, "value", s2));
        return [v2(j2) + "=" + E2];
      }
      return [v2(j2) + "=" + v2(u2(h2, R.encoder, y2, "value", s2))];
    }
    return [v2(n2) + "=" + v2(String(h2))];
  }
  var k2, x2 = [];
  if (void 0 === h2)
    return x2;
  if ("comma" === e2 && m(h2))
    k2 = [{ value: h2.length > 0 ? h2.join(",") || null : void 0 }];
  else if (m(f2))
    k2 = f2;
  else {
    var C2 = Object.keys(h2);
    k2 = a2 ? C2.sort(a2) : C2;
  }
  for (var N2 = 0; N2 < k2.length; ++N2) {
    var T2 = k2[N2], F2 = "object" == typeof T2 && void 0 !== T2.value ? T2.value : h2[T2];
    if (!i2 || null !== F2) {
      var D2 = m(h2) ? "function" == typeof e2 ? e2(n2, T2) : n2 : n2 + (c2 ? "." + T2 : "[" + T2 + "]");
      w(x2, t3(F2, D2, e2, o2, i2, u2, f2, a2, c2, l2, s2, v2, p2, y2));
    }
  }
  return x2;
}, k = Object.prototype.hasOwnProperty, x = Array.isArray, C = { allowDots: false, allowPrototypes: false, arrayLimit: 20, charset: "utf-8", charsetSentinel: false, comma: false, decoder: d.decode, delimiter: "&", depth: 5, ignoreQueryPrefix: false, interpretNumericEntities: false, parameterLimit: 1e3, parseArrays: true, plainObjects: false, strictNullHandling: false }, N = function(t4) {
  return t4.replace(/&#(\d+);/g, function(t5, r2) {
    return String.fromCharCode(parseInt(r2, 10));
  });
}, T = function(t4, r2) {
  return t4 && "string" == typeof t4 && r2.comma && t4.indexOf(",") > -1 ? t4.split(",") : t4;
}, F = function(t4, r2, n2, e2) {
  if (t4) {
    var o2 = n2.allowDots ? t4.replace(/\.([^.[]+)/g, "[$1]") : t4, i2 = /(\[[^[\]]*])/g, u2 = n2.depth > 0 && /(\[[^[\]]*])/.exec(o2), f2 = u2 ? o2.slice(0, u2.index) : o2, a2 = [];
    if (f2) {
      if (!n2.plainObjects && k.call(Object.prototype, f2) && !n2.allowPrototypes)
        return;
      a2.push(f2);
    }
    for (var c2 = 0; n2.depth > 0 && null !== (u2 = i2.exec(o2)) && c2 < n2.depth; ) {
      if (c2 += 1, !n2.plainObjects && k.call(Object.prototype, u2[1].slice(1, -1)) && !n2.allowPrototypes)
        return;
      a2.push(u2[1]);
    }
    return u2 && a2.push("[" + o2.slice(u2.index) + "]"), function(t5, r3, n3, e3) {
      for (var o3 = e3 ? r3 : T(r3, n3), i3 = t5.length - 1; i3 >= 0; --i3) {
        var u3, f3 = t5[i3];
        if ("[]" === f3 && n3.parseArrays)
          u3 = [].concat(o3);
        else {
          u3 = n3.plainObjects ? /* @__PURE__ */ Object.create(null) : {};
          var a3 = "[" === f3.charAt(0) && "]" === f3.charAt(f3.length - 1) ? f3.slice(1, -1) : f3, c3 = parseInt(a3, 10);
          n3.parseArrays || "" !== a3 ? !isNaN(c3) && f3 !== a3 && String(c3) === a3 && c3 >= 0 && n3.parseArrays && c3 <= n3.arrayLimit ? (u3 = [])[c3] = o3 : "__proto__" !== a3 && (u3[a3] = o3) : u3 = { 0: o3 };
        }
        o3 = u3;
      }
      return o3;
    }(a2, r2, n2, e2);
  }
}, D = function(t4, r2) {
  var n2 = function(t5) {
    if (!t5)
      return C;
    if (null != t5.decoder && "function" != typeof t5.decoder)
      throw new TypeError("Decoder has to be a function.");
    if (void 0 !== t5.charset && "utf-8" !== t5.charset && "iso-8859-1" !== t5.charset)
      throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");
    return { allowDots: void 0 === t5.allowDots ? C.allowDots : !!t5.allowDots, allowPrototypes: "boolean" == typeof t5.allowPrototypes ? t5.allowPrototypes : C.allowPrototypes, arrayLimit: "number" == typeof t5.arrayLimit ? t5.arrayLimit : C.arrayLimit, charset: void 0 === t5.charset ? C.charset : t5.charset, charsetSentinel: "boolean" == typeof t5.charsetSentinel ? t5.charsetSentinel : C.charsetSentinel, comma: "boolean" == typeof t5.comma ? t5.comma : C.comma, decoder: "function" == typeof t5.decoder ? t5.decoder : C.decoder, delimiter: "string" == typeof t5.delimiter || d.isRegExp(t5.delimiter) ? t5.delimiter : C.delimiter, depth: "number" == typeof t5.depth || false === t5.depth ? +t5.depth : C.depth, ignoreQueryPrefix: true === t5.ignoreQueryPrefix, interpretNumericEntities: "boolean" == typeof t5.interpretNumericEntities ? t5.interpretNumericEntities : C.interpretNumericEntities, parameterLimit: "number" == typeof t5.parameterLimit ? t5.parameterLimit : C.parameterLimit, parseArrays: false !== t5.parseArrays, plainObjects: "boolean" == typeof t5.plainObjects ? t5.plainObjects : C.plainObjects, strictNullHandling: "boolean" == typeof t5.strictNullHandling ? t5.strictNullHandling : C.strictNullHandling };
  }(r2);
  if ("" === t4 || null == t4)
    return n2.plainObjects ? /* @__PURE__ */ Object.create(null) : {};
  for (var e2 = "string" == typeof t4 ? function(t5, r3) {
    var n3, e3 = {}, o3 = (r3.ignoreQueryPrefix ? t5.replace(/^\?/, "") : t5).split(r3.delimiter, Infinity === r3.parameterLimit ? void 0 : r3.parameterLimit), i3 = -1, u3 = r3.charset;
    if (r3.charsetSentinel)
      for (n3 = 0; n3 < o3.length; ++n3)
        0 === o3[n3].indexOf("utf8=") && ("utf8=%E2%9C%93" === o3[n3] ? u3 = "utf-8" : "utf8=%26%2310003%3B" === o3[n3] && (u3 = "iso-8859-1"), i3 = n3, n3 = o3.length);
    for (n3 = 0; n3 < o3.length; ++n3)
      if (n3 !== i3) {
        var f3, a3, c2 = o3[n3], l2 = c2.indexOf("]="), s2 = -1 === l2 ? c2.indexOf("=") : l2 + 1;
        -1 === s2 ? (f3 = r3.decoder(c2, C.decoder, u3, "key"), a3 = r3.strictNullHandling ? null : "") : (f3 = r3.decoder(c2.slice(0, s2), C.decoder, u3, "key"), a3 = d.maybeMap(T(c2.slice(s2 + 1), r3), function(t6) {
          return r3.decoder(t6, C.decoder, u3, "value");
        })), a3 && r3.interpretNumericEntities && "iso-8859-1" === u3 && (a3 = N(a3)), c2.indexOf("[]=") > -1 && (a3 = x(a3) ? [a3] : a3), e3[f3] = k.call(e3, f3) ? d.combine(e3[f3], a3) : a3;
      }
    return e3;
  }(t4, n2) : t4, o2 = n2.plainObjects ? /* @__PURE__ */ Object.create(null) : {}, i2 = Object.keys(e2), u2 = 0; u2 < i2.length; ++u2) {
    var f2 = i2[u2], a2 = F(f2, e2[f2], n2, "string" == typeof t4);
    o2 = d.merge(o2, a2, n2);
  }
  return d.compact(o2);
}, $ = /* @__PURE__ */ function() {
  function t4(t5, r2, n3) {
    var e2, o2;
    this.name = t5, this.definition = r2, this.bindings = null != (e2 = r2.bindings) ? e2 : {}, this.wheres = null != (o2 = r2.wheres) ? o2 : {}, this.config = n3;
  }
  var n2 = t4.prototype;
  return n2.matchesUrl = function(t5) {
    var r2 = this;
    if (!this.definition.methods.includes("GET"))
      return false;
    var n3 = this.template.replace(/(\/?){([^}?]*)(\??)}/g, function(t6, n4, e3, o3) {
      var i3, u3 = "(?<" + e3 + ">" + ((null == (i3 = r2.wheres[e3]) ? void 0 : i3.replace(/(^\^)|(\$$)/g, "")) || "[^/?]+") + ")";
      return o3 ? "(" + n4 + u3 + ")?" : "" + n4 + u3;
    }).replace(/^\w+:\/\//, ""), e2 = t5.replace(/^\w+:\/\//, "").split("?"), o2 = e2[0], i2 = e2[1], u2 = new RegExp("^" + n3 + "/?$").exec(o2);
    return !!u2 && { params: u2.groups, query: D(i2) };
  }, n2.compile = function(t5) {
    var r2 = this, n3 = this.parameterSegments;
    return n3.length ? this.template.replace(/{([^}?]+)(\??)}/g, function(e2, o2, i2) {
      var u2, f2, a2;
      if (!i2 && [null, void 0].includes(t5[o2]))
        throw new Error("Ziggy error: '" + o2 + "' parameter is required for route '" + r2.name + "'.");
      if (n3[n3.length - 1].name === o2 && ".*" === r2.wheres[o2])
        return encodeURIComponent(null != (a2 = t5[o2]) ? a2 : "").replace(/%2F/g, "/");
      if (r2.wheres[o2] && !new RegExp("^" + (i2 ? "(" + r2.wheres[o2] + ")?" : r2.wheres[o2]) + "$").test(null != (u2 = t5[o2]) ? u2 : ""))
        throw new Error("Ziggy error: '" + o2 + "' parameter does not match required format '" + r2.wheres[o2] + "' for route '" + r2.name + "'.");
      return encodeURIComponent(null != (f2 = t5[o2]) ? f2 : "");
    }).replace(/\/+$/, "") : this.template;
  }, r(t4, [{ key: "template", get: function() {
    return ((this.config.absolute ? this.definition.domain ? "" + this.config.url.match(/^\w+:\/\//)[0] + this.definition.domain + (this.config.port ? ":" + this.config.port : "") : this.config.url : "") + "/" + this.definition.uri).replace(/\/+$/, "");
  } }, { key: "parameterSegments", get: function() {
    var t5, r2;
    return null != (t5 = null == (r2 = this.template.match(/{[^}?]+\??}/g)) ? void 0 : r2.map(function(t6) {
      return { name: t6.replace(/{|\??}/g, ""), required: !/\?}$/.test(t6) };
    })) ? t5 : [];
  } }]), t4;
}(), A = /* @__PURE__ */ function(t4) {
  var e2, i2;
  function u2(r2, e3, o2, i3) {
    var u3;
    if (void 0 === o2 && (o2 = true), (u3 = t4.call(this) || this).t = null != i3 ? i3 : "undefined" != typeof Ziggy ? Ziggy : null == globalThis ? void 0 : globalThis.Ziggy, u3.t = n({}, u3.t, { absolute: o2 }), r2) {
      if (!u3.t.routes[r2])
        throw new Error("Ziggy error: route '" + r2 + "' is not in the route list.");
      u3.i = new $(r2, u3.t.routes[r2], u3.t), u3.u = u3.l(e3);
    }
    return u3;
  }
  i2 = t4, (e2 = u2).prototype = Object.create(i2.prototype), e2.prototype.constructor = e2, o(e2, i2);
  var f2 = u2.prototype;
  return f2.toString = function() {
    var t5 = this, r2 = Object.keys(this.u).filter(function(r3) {
      return !t5.i.parameterSegments.some(function(t6) {
        return t6.name === r3;
      });
    }).filter(function(t6) {
      return "_query" !== t6;
    }).reduce(function(r3, e3) {
      var o2;
      return n({}, r3, ((o2 = {})[e3] = t5.u[e3], o2));
    }, {});
    return this.i.compile(this.u) + function(t6, r3) {
      var n2, e3 = t6, o2 = function(t7) {
        if (!t7)
          return R;
        if (null != t7.encoder && "function" != typeof t7.encoder)
          throw new TypeError("Encoder has to be a function.");
        var r4 = t7.charset || R.charset;
        if (void 0 !== t7.charset && "utf-8" !== t7.charset && "iso-8859-1" !== t7.charset)
          throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");
        var n3 = l.default;
        if (void 0 !== t7.format) {
          if (!b.call(l.formatters, t7.format))
            throw new TypeError("Unknown format option provided.");
          n3 = t7.format;
        }
        var e4 = l.formatters[n3], o3 = R.filter;
        return ("function" == typeof t7.filter || m(t7.filter)) && (o3 = t7.filter), { addQueryPrefix: "boolean" == typeof t7.addQueryPrefix ? t7.addQueryPrefix : R.addQueryPrefix, allowDots: void 0 === t7.allowDots ? R.allowDots : !!t7.allowDots, charset: r4, charsetSentinel: "boolean" == typeof t7.charsetSentinel ? t7.charsetSentinel : R.charsetSentinel, delimiter: void 0 === t7.delimiter ? R.delimiter : t7.delimiter, encode: "boolean" == typeof t7.encode ? t7.encode : R.encode, encoder: "function" == typeof t7.encoder ? t7.encoder : R.encoder, encodeValuesOnly: "boolean" == typeof t7.encodeValuesOnly ? t7.encodeValuesOnly : R.encodeValuesOnly, filter: o3, format: n3, formatter: e4, serializeDate: "function" == typeof t7.serializeDate ? t7.serializeDate : R.serializeDate, skipNulls: "boolean" == typeof t7.skipNulls ? t7.skipNulls : R.skipNulls, sort: "function" == typeof t7.sort ? t7.sort : null, strictNullHandling: "boolean" == typeof t7.strictNullHandling ? t7.strictNullHandling : R.strictNullHandling };
      }(r3);
      "function" == typeof o2.filter ? e3 = (0, o2.filter)("", e3) : m(o2.filter) && (n2 = o2.filter);
      var i3 = [];
      if ("object" != typeof e3 || null === e3)
        return "";
      var u3 = h[r3 && r3.arrayFormat in h ? r3.arrayFormat : r3 && "indices" in r3 ? r3.indices ? "indices" : "repeat" : "indices"];
      n2 || (n2 = Object.keys(e3)), o2.sort && n2.sort(o2.sort);
      for (var f3 = 0; f3 < n2.length; ++f3) {
        var a2 = n2[f3];
        o2.skipNulls && null === e3[a2] || w(i3, S(e3[a2], a2, u3, o2.strictNullHandling, o2.skipNulls, o2.encode ? o2.encoder : null, o2.filter, o2.sort, o2.allowDots, o2.serializeDate, o2.format, o2.formatter, o2.encodeValuesOnly, o2.charset));
      }
      var c2 = i3.join(o2.delimiter), s2 = true === o2.addQueryPrefix ? "?" : "";
      return o2.charsetSentinel && (s2 += "iso-8859-1" === o2.charset ? "utf8=%26%2310003%3B&" : "utf8=%E2%9C%93&"), c2.length > 0 ? s2 + c2 : "";
    }(n({}, r2, this.u._query), { addQueryPrefix: true, arrayFormat: "indices", encodeValuesOnly: true, skipNulls: true, encoder: function(t6, r3) {
      return "boolean" == typeof t6 ? Number(t6) : r3(t6);
    } });
  }, f2.v = function(t5) {
    var r2 = this;
    t5 ? this.t.absolute && t5.startsWith("/") && (t5 = this.p().host + t5) : t5 = this.h();
    var e3 = {}, o2 = Object.entries(this.t.routes).find(function(n2) {
      return e3 = new $(n2[0], n2[1], r2.t).matchesUrl(t5);
    }) || [void 0, void 0];
    return n({ name: o2[0] }, e3, { route: o2[1] });
  }, f2.h = function() {
    var t5 = this.p(), r2 = t5.pathname, n2 = t5.search;
    return (this.t.absolute ? t5.host + r2 : r2.replace(this.t.url.replace(/^\w*:\/\/[^/]+/, ""), "").replace(/^\/+/, "/")) + n2;
  }, f2.current = function(t5, r2) {
    var e3 = this.v(), o2 = e3.name, i3 = e3.params, u3 = e3.query, f3 = e3.route;
    if (!t5)
      return o2;
    var a2 = new RegExp("^" + t5.replace(/\./g, "\\.").replace(/\*/g, ".*") + "$").test(o2);
    if ([null, void 0].includes(r2) || !a2)
      return a2;
    var c2 = new $(o2, f3, this.t);
    r2 = this.l(r2, c2);
    var l2 = n({}, i3, u3);
    return !(!Object.values(r2).every(function(t6) {
      return !t6;
    }) || Object.values(l2).some(function(t6) {
      return void 0 !== t6;
    })) || Object.entries(r2).every(function(t6) {
      return l2[t6[0]] == t6[1];
    });
  }, f2.p = function() {
    var t5, r2, n2, e3, o2, i3, u3 = "undefined" != typeof window ? window.location : {}, f3 = u3.host, a2 = u3.pathname, c2 = u3.search;
    return { host: null != (t5 = null == (r2 = this.t.location) ? void 0 : r2.host) ? t5 : void 0 === f3 ? "" : f3, pathname: null != (n2 = null == (e3 = this.t.location) ? void 0 : e3.pathname) ? n2 : void 0 === a2 ? "" : a2, search: null != (o2 = null == (i3 = this.t.location) ? void 0 : i3.search) ? o2 : void 0 === c2 ? "" : c2 };
  }, f2.has = function(t5) {
    return Object.keys(this.t.routes).includes(t5);
  }, f2.l = function(t5, r2) {
    var e3 = this;
    void 0 === t5 && (t5 = {}), void 0 === r2 && (r2 = this.i), null != t5 || (t5 = {}), t5 = ["string", "number"].includes(typeof t5) ? [t5] : t5;
    var o2 = r2.parameterSegments.filter(function(t6) {
      return !e3.t.defaults[t6.name];
    });
    if (Array.isArray(t5))
      t5 = t5.reduce(function(t6, r3, e4) {
        var i4, u3;
        return n({}, t6, o2[e4] ? ((i4 = {})[o2[e4].name] = r3, i4) : "object" == typeof r3 ? r3 : ((u3 = {})[r3] = "", u3));
      }, {});
    else if (1 === o2.length && !t5[o2[0].name] && (t5.hasOwnProperty(Object.values(r2.bindings)[0]) || t5.hasOwnProperty("id"))) {
      var i3;
      (i3 = {})[o2[0].name] = t5, t5 = i3;
    }
    return n({}, this.m(r2), this.g(t5, r2));
  }, f2.m = function(t5) {
    var r2 = this;
    return t5.parameterSegments.filter(function(t6) {
      return r2.t.defaults[t6.name];
    }).reduce(function(t6, e3, o2) {
      var i3, u3 = e3.name;
      return n({}, t6, ((i3 = {})[u3] = r2.t.defaults[u3], i3));
    }, {});
  }, f2.g = function(t5, r2) {
    var e3 = r2.bindings, o2 = r2.parameterSegments;
    return Object.entries(t5).reduce(function(t6, r3) {
      var i3, u3, f3 = r3[0], a2 = r3[1];
      if (!a2 || "object" != typeof a2 || Array.isArray(a2) || !o2.some(function(t7) {
        return t7.name === f3;
      }))
        return n({}, t6, ((u3 = {})[f3] = a2, u3));
      if (!a2.hasOwnProperty(e3[f3])) {
        if (!a2.hasOwnProperty("id"))
          throw new Error("Ziggy error: object passed as '" + f3 + "' parameter is missing route model binding key '" + e3[f3] + "'.");
        e3[f3] = "id";
      }
      return n({}, t6, ((i3 = {})[f3] = a2[e3[f3]], i3));
    }, {});
  }, f2.valueOf = function() {
    return this.toString();
  }, f2.check = function(t5) {
    return this.has(t5);
  }, r(u2, [{ key: "params", get: function() {
    var t5 = this.v();
    return n({}, t5.params, t5.query);
  } }]), u2;
}(/* @__PURE__ */ f(String)), I = { install: function(t4, r2) {
  var n2 = function(t5, n3, e2, o2) {
    return void 0 === o2 && (o2 = r2), function(t6, r3, n4, e3) {
      var o3 = new A(t6, r3, n4, e3);
      return t6 ? o3.toString() : o3;
    }(t5, n3, e2, o2);
  };
  t4.mixin({ methods: { route: n2 } }), parseInt(t4.version) > 2 && t4.provide("route", n2);
} };
createServer(
  (page) => createInertiaApp({
    page,
    render: renderToString,
    resolve: (name) => {
      const pages = /* @__PURE__ */ Object.assign({ "./Pages/AccountDeleted.vue": __vite_glob_0_0, "./Pages/Authentication/Create.vue": __vite_glob_0_1, "./Pages/Authentication/Forgot.vue": __vite_glob_0_2, "./Pages/Authentication/Login.vue": __vite_glob_0_3, "./Pages/Dashboard.vue": __vite_glob_0_4, "./Pages/Forum/Create.vue": __vite_glob_0_5, "./Pages/Forum/Index.vue": __vite_glob_0_6, "./Pages/Forum/Reply.vue": __vite_glob_0_7, "./Pages/Settings/Edit.vue": __vite_glob_0_8, "./Pages/Settings/Partials/DeleteUserForm.vue": __vite_glob_0_9, "./Pages/Settings/Partials/UpdatePasswordForm.vue": __vite_glob_0_10, "./Pages/Settings/Partials/UpdateProfileInformationForm.vue": __vite_glob_0_11, "./Pages/Store/Index.vue": __vite_glob_0_12, "./Pages/Users/Index.vue": __vite_glob_0_13, "./Pages/Users/Profile.vue": __vite_glob_0_14, "./Pages/Welcome.vue": __vite_glob_0_15 });
      return pages[`./Pages/${name}.vue`];
    },
    setup({ app, props, plugin }) {
      return createSSRApp({
        render: () => h$1(app, props)
      }).use(plugin).use(I, {
        ...page.props.ziggy,
        location: new URL(page.props.ziggy.location)
      });
    }
  })
);
