<?php

return [
    'name' => env('APP_NAME'),
    'logo' => '/img/logo_Halloween.png',
    'icon' => '/img/icon_Halloween.png',

    'storage_url' => 'http://cdn.otorium.local',
  
    'renderer' => [
        'url' => 'http://south.otorium.local',
        'key' => 'dAktdYZ2SBABYCmK',
        'default_filename' => '40oFb9RYEBLwvzPNse3Ajh623',
        'previews_enabled' => true
    ],

    'socials' => [
        'discord' => 'https://discord.gg/n9vcmaR8Y2',
        'twitter' => '#'
    ],
];