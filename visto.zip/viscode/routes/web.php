<?php

use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\GrabController;
use App\Http\Controllers\USController;
use App\Http\Controllers\TestCon;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['as' => 'my.', 'prefix' => 'my'], function() { 
  
Route::group(['middleware' => 'auth'], function() {  
Route::group(['as' => 'dashboard.', 'prefix' => 'dashboard'], function() { 
Route::get('/', [GrabController::class, 'DashboardIndex'])->name('page');
Route::post('/', [GrabController::class, 'DashboardVal'])->name('validate');
});
  
});
  
});

Route::group(['as' => 'user.', 'prefix' => 'user'], function() {
  Route::get('/discover', [GrabController::class, 'UserIndex'])->name('page');
    Route::get('/profile/{username}', [GrabController::class, 'ProfileIndex'])->name('profile');   
    Route::group(['middleware' => 'auth'], function() {
       Route::group(['as' => 'settings.', 'prefix' => 'settings'], function() { 
       Route::get('/', [USController::class, 'edit'])->name('edit');
       Route::patch('/', [USController::class, 'update'])->name('update');
       Route::delete('/', [USController::class, 'destroy'])->name('destroy');
       }); 
    });  
});    

Route::group(['as' => 'forum.', 'prefix' => 'forum'], function() {
  Route::get('/{id}', [GrabController::class, 'ForumIndex'])->name('page');
  Route::group(['as' => 'create.', 'prefix' => 'create'], function() { 
  Route::get('/{id}', [GrabController::class, 'ForumCreate'])->name('page');
  Route::post('/{id}/validate', [GrabController::class, 'ForumVal'])->name('validate');
    });
});     



Route::group(['as' => 'auth.', 'prefix' => 'auth'], function() {
Route::post('logout', [AuthController::class, 'UserExit'])->name('logout');

  Route::group(['middleware' => 'guest'], function() {
    Route::group(['as' => 'login.', 'prefix' => 'login'], function() {  
      
    Route::get('/', [AuthController::class, 'LoginIndex'])->name('page');
    Route::post('/', [AuthController::class, 'LoginVal'])->name('validate');
});     

Route::group(['as' => 'register.', 'prefix' => 'register'], function() { 
  
Route::get('/', [AuthController::class, 'RegisterIndex'])->name('page');   
Route::post('/', [AuthController::class, 'RegisterVal'])->name('validate');   
});
    
Route::group(['as' => 'forgot.', 'prefix' => 'forgot'], function() {  
Route::get('/', [AuthController::class, 'ForgotIndex'])->name('page');
     });  
  });
});
  
Route::get('/', function () {
    return Inertia::render('Welcome');
})->middleware(['guest'])->name('Welcome');

Route::get('/deletion', function () {
    return Inertia::render('AccountDeleted');
})->name('removed');

Route::get('/store', function () {
    return Inertia::render('Store/Index');
})->name('Store');

Route::get('/discord', [TestCon::class, 'index'])->name('test');
