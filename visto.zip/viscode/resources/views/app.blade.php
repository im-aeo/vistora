<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">

      <title inertia>{{ config('app.name', 'Laravel') }}</title>
      
      <!-- Vistora Accuracy Stuff --> 
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
      <meta name="description" content="Switch between website themes">
      <meta name="robots" content="index,follow">
      <meta property="og:title" content="{{ config('app.name', 'Laravel') }}">
      <meta property="og:description" content="{{ config('app.name', 'Laravel') }}">
      <meta property="og:site_name" content="{{ config('app.name', 'Laravel') }}">
      <meta name="keywords" content="vistora, vistora.xyz, vistora.com, vistora 3d, vistora game, vistora trade, vistora forum, vistora sandbox, vistora avatar, vistora vens, vens, lottery, forum, store, 3d, avatars, ugc, {{ config('app.name', 'Laravel') }}">
      
      <meta name="language" content="English">
      
      <meta name="author" content="{{ config('app.name', 'Laravel') }}">
      
      <meta name="twitter:title" content="{{ config('app.name', 'Laravel') }}">
      <meta name="twitter:description" content="Switch between website themes">
      <meta name="twitter:site" content="@vistoraofficial">
     
      
      <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v5.15.1/css/pro.min.css">
    
      <link
      rel="shortcut icon"
      type="image/x-icon"
      href="./assets/favicon/favicon.ico"
    />
      <!-- Fonts -->
      <link rel="stylesheet" href="https://fonts.bunny.net/css?family=ubuntu:500">
       <script src="https://unpkg.com/simple-notifications-solution/dist/Notifications.js"></script> 
      <!-- Scripts -->
      @routes
      @inertiaHead
      @vite(['resources/js/app.js', "resources/js/Pages/{$page['component']}.vue"])
    </head>
    <body style="background:rgb(28, 28, 28);">
        @inertia
    </body> 
</html>
