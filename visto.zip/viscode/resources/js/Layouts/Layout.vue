<script setup>
import { ref } from 'vue';
import { Head, router, Link, usePage } from '@inertiajs/vue3';

defineProps({
    title: String,
    isActive: false,
    showNavbar: true
});

const logout = () => {
    router.post(route('auth.logout'));
};

document.addEventListener('DOMContentLoaded', () => {
  (document.querySelectorAll('.notification .delete') || []).forEach(($delete) => {
    $notification = $delete.parentNode;

    $delete.addEventListener('click', () => {
      $notification.parentNode.removeChild($notification);
    });
  });
});

var notifications = new Notifications();
notifications.init();
</script>

<template>
<Head :title="title" />

<nav class="navbar is-spaced has-shadow">
<div class="container">
 <div class="navbar-brand">
    <Link class="navbar-item" :href="route('Welcome')">
    <img class="index-logo" src="/branding/flat_logo.svg" alt="">
    </Link> 
    <a :aria-expanded="isActive" :class="{ 'is-active': isActive }" role="button" class="navbar-burger" aria-label="menu" data-target="collapse" @click="isActive = !isActive">
          <span aria-hidden="true" />
          <span aria-hidden="true" />
          <span aria-hidden="true" />
         </a>
  </div> 
     <div id="collapse" :class="{ 'is-active': isActive }"  class="navbar-menu">
       <div class="navbar-start">
        <Link class="navbar-item" :href="route('Welcome')">Dashboard</Link>
        <Link class="navbar-item" :href="route('Store')">Store</Link>
        <Link class="navbar-item" :href="route('forum.page', { id: 1 })">Forum</Link>
        <Link class="navbar-item" :href="route('user.page')">Discover</Link>
        <Link class="navbar-item has-text-danger" :href="route('user.page')" v-if="$page.props.auth.user && $page.props.auth.user.staff == '1'">Admin</Link>
        <div class="navbar-item has-dropdown is-hoverable">
        <a class="navbar-link">More</a>
        
        <div class="navbar-dropdown">
        <a class="navbar-item" href="#">
        <i class="fal fa-align-left"></i>&nbsp;&nbsp;Public Indexing</a>
        <a class="navbar-item" href="#">
        <i class="fad fa-people-arrows"></i>&nbsp;&nbsp;Compete</a>
        <a class="navbar-item" href="#">
        <i class="fad fa-dollar-sign"></i>&nbsp;&nbsp;Promocodes</a>
        <a class="navbar-item" href="#">
        <i class="fad fa-user-cog"></i>&nbsp;&nbsp;Settings</a>
        
        <hr class="navbar-divider">
        <Link class="navbar-item"><i class="fab fa-twitter"></i>&nbsp;&nbsp;Twitter</Link>
        <Link class="navbar-item"><i class="fab fa-discord"></i>&nbsp;&nbsp;Discord</Link>
        </div>
     </div>
    </div>    
        <div class="navbar-end" v-if="$page.props.auth.user">
        
        <div class="navbar-item">
        
        <a href="https://vistora.xyz/user/relations" class="navbar-item tooltip is-tooltip-bottom" data-tooltip="Relations">
        <i class="fad fa-handshake"></i>
        </a> 
        <a href="https://vistora.xyz/user/trades" class="navbar-item tooltip is-tooltip-bottom" data-tooltip="Trades">
        <i class="fad fa-people-arrows"></i>
        </a> 
        
        <a href="https://vistora.xyz/user/transactions" class="navbar-item tooltip is-tooltip-bottom" data-tooltip="Transactions">{{ $page.props.auth.user.vens }} Vens</a>
        
        <div class="navbar-item has-dropdown is-hoverable">
        <a class="navbar-link">
        <span class="navbar-headshot is-hidden-mobile">
        <img class="navbar-headshot-image" src="/props/aeo_headshot.png" alt="Avatar Render">
        </span> 
         {{ $page.props.auth.user.name }}
        </a> 
        <div class="navbar-dropdown is-boxed is-right">
        <Link class="navbar-item" :href="route('user.profile', { username: $page.props.auth.user.name })"> 
        <i class="fad fa-user"></i>&nbsp;&nbsp;Profile</Link>
        <a class="navbar-item" href="https://vistora.xyz/user/avatar">
        <i class="fad fa-sparkles"></i>&nbsp;&nbsp;Avatar</a>
        <a class="navbar-item" href="https://vistora.xyz/user/profile/aeo1/inventory">
        <i class="fad fa-suitcase"></i>&nbsp;&nbsp;Inventory</a> 
        <a class="navbar-item" href="https://vistora.xyz/user/settings">
        <i class="fad fa-user-cog"></i>&nbsp;&nbsp;Settings</a>
        <hr class="navbar-divider">
        <Link :href="route('auth.logout')" method="post" class="navbar-item has-text-danger">
        <i class="fal fa-power-off"></i>&nbsp;&nbsp;
        Sign Out
        </Link>
        </div>
      </div>
    </div>
</div>
           <div class="navbar-end" v-else>
           <div class="navbar-item">
           <div class="buttons">
           <Link class="button is-light" :href="route('auth.login.page')">Login</Link>
           <Link class="button is-info" :href="route('auth.register.page')"><strong>Hop in</strong></Link>
           </div>
         </div>
       </div>
       </div>
       </div>
</nav>
    <slot/>
    <p v-if="$page.props.flash.message" class="notification is-success" data-close="self">
        {{ $page.props.flash.message }}
         <button class="button has-text-success">OK</button>
      </p>
      
    <button class="chat-open-button button is-info is-rounded">Chat</button> 
      <div class="chat-popup" id="chat-form">
        <div class="box chat-form-container">
        <span class="delete is-pulled-right"></span> 
        <div class="title is-6 mb-2">Chat</div> 
        <hr class="mt-1 mb-1 w-100">
        <div class="chat-container"> 
        </div>
        </div>
        </div> 
    <hr>
    <footer class="footer has-text-centered">
     <div class="content">
      <div class="is-size-5 has-text-weight-bold mb-3">Vistora</div> 
       <div class="columns is-centered is-mobile">
        <div class="column is-3">
         <div class="is-size-6 has-text-weight-semibold">Navigate</div>
         <Link :href="route('Welcome')">Home</Link><br>
         <Link :href="route('Store')">Store</Link><br>
         <Link :href="route('forum.page', { id: 1 })">Forum</Link><br>
       </div>
       <div class="column is-3">
        <div class="is-size-6 has-text-weight-semibold">Legal</div>
        <a href="https://vistora.xyz/legal/terms">Terms of Service</a><br>
        <a href="https://vistora.xyz/legal/privacy">Privacy</a><br>
       </div>
       <div class="column is-3">
         <div class="is-size-6 has-text-weight-semibold">Contact</div>
         <a target="#" href="mailto:support@vistora.xyz">Email</a><br>
         <a target="#" href="https://discord.gg/qwRYqbrBmG">Discord</a><br>
         <a target="#" href="https://twitter.com/vistoraofficial">Twitter</a><br> 
       </div>
     </div> 
     <div class="is-size-6">Vistora &copy; - 2020-21</div>
  </div>
</footer>
</template>