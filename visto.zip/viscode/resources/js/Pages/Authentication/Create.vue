<script setup>
import Layout from '@/Layouts/Layout.vue';

import { useForm } from '@inertiajs/vue3';

defineProps({
    canResetPassword: Boolean,
    status: String,
});

const form = useForm({
    name: '',
    email: '',
    password: '',
});

const submit = () => {
    form.post(route('auth.register.validate'), {
        onFinish: () => form.reset('password'),
    });
};
</script>

<template>
<Layout title="Log in">
<section class="hero is-fullheight">
   <div class="hero-body">
     <div class="container">
      <div class="columns is-centered">
        <div class="column is-6-tablet is-5-desktop is-5-widescreen">
         <div class="box">
         <div class="is-size-5">Register</div> 
         <div class="is-size-6 has-text-grey-light mb-3">Create a new account and hop right in the action</div> 
         <form @submit.prevent="submit">
         <fieldset>
            <div class="field">
            <label for="name" class="label">Username</label>
            <div class="control has-icons-left">
            <input id="name" v-model="form.name" type="text" placeholder="Username" class="input">
            <span class="icon is-small is-left">
            <i class="fa fa-user"></i>
            </span>
            <div v-if="form.errors.name">{{ form.errors.name }}</div>
       </div> 
    </div> 
    
            <div class="field">
            <label for="email" class="label">E-mail</label>
            <div class="control has-icons-left">
            <input id="email" v-model="form.email" type="email" placeholder="E-mail" class="input">
            <span class="icon is-small is-left">
            <i class="fa fa-user"></i>
            </span>
            <div v-if="form.errors.email">{{ form.errors.email }}</div>
       </div> 
    </div> 
    
            <div class="field">
            <label for="password" class="label">Password</label>
            <div class="control has-icons-left">
            <input id="password" v-model="form.password" type="password" placeholder="Password" class="input"> 
            <span class="icon is-small is-left">
            <i class="fa fa-key"></i>
            </span>
            <div v-if="form.errors.password">{{ form.errors.password }}</div>
        </div>
     </div>
            <div class="field">
            <div class="buttons">
            <button type="submit" class="button is-info" :disabled="form.processing">Register</button>
            </div>
         </div> 
       </fieldset>
    </form>
</div>
     <center><Link :href="route('auth.login.page')">Got an account?</Link></center>
    </div>
   </div>
  </div>
 </div>
</section>
</Layout>
</template>