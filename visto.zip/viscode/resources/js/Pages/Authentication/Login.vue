<script setup>
import Layout from '@/Layouts/Layout.vue';
import { useForm } from '@inertiajs/vue3';
import { nextTick, ref } from 'vue';

defineProps({
    canResetPassword: Boolean,
    status: String,
});
const ConfirmingAuth = ref(false);

const form = useForm({
    name: '',
    password: '',
    remember: false,
});

const submit = () => {
    form.transform(data => ({
        ...data,
        remember: form.remember ? 'on' : '',
    })).post(route('auth.login.validate'), {
        onFinish: () => form.reset('password'),
    });
};

const ConfirmUserAuth = () => {
    ConfirmingAuth.value = true;
};
</script>

<template>
<Layout title="Log in">
<section class="hero is-fullheight">
   <div class="hero-body">
     <div class="container">
      <div class="columns is-centered">
        <div class="column is-6-tablet is-5-desktop is-5-widescreen">
         <div class="box">
         <div class="is-size-5">Login</div> 
         <div class="is-size-6 has-text-grey-light mb-3">Lets continue from where you left</div> 
         <form @submit.prevent="submit">
         <fieldset>
            <div class="field">
            <label for="name" class="label">Username</label>
            <div class="control has-icons-left">
            <input id="name" v-model="form.name" type="text" placeholder="Username" class="input">
            <span class="icon is-small is-left">
            <i class="fa fa-user"></i>
            </span>
            <div v-if="form.errors.name">{{ form.errors.name }}</div>
       </div> 
    </div> 
            <div class="field">
            <label for="password" class="label">Password</label>
            <div class="control has-icons-left">
            <input id="password" v-model="form.password" type="password" placeholder="Password" class="input"> 
            <span class="icon is-small is-left">
            <i class="fa fa-key"></i>
            </span>
            <div v-if="form.errors.password">{{ form.errors.password }}</div>
        </div>
     </div>
            <div class="field">
            <label class="checkbox">
            <input type="checkbox" v-model="form.remember">Remember me</label>
         </div> 
            <div class="field">
            <div class="buttons">
            <button type="submit" class="button is-info" v-bind:class="{ 'is-loading': ConfirmingAuth }" :disabled="form.processing" @click="ConfirmUserAuth">Login</button>
            <a :href="route('auth.forgot.page')" class="button">Forgot?</a>
            </div>
         </div> 
       </fieldset>
    </form>
</div>
     <center><Link :href="route('auth.register.page')">No account?</Link></center>
    </div>
   </div>
  </div>
 </div>
</section>
</Layout>
</template>