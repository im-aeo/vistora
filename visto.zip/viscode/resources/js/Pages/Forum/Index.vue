<script setup>
import Layout from '@/Layouts/Layout.vue';
</script>

<template>
<Layout title="Forum">
<div class="container">
     <section class="section">
          <div class="columns">
         <div class="column is-3">
           <span slot="secondary">
           <div class="title">{{ topic.name }}</div>
           <div class="subtitle is-6 has-text-grey-light">{{ topic.description }}</div>
           <div class="buttons">
           <Link v-if="$page.props.auth.user.staff >= '1' && topic.is_staff_only_posting == '1'"  class="button is-info is-rounded is-fullwidth" :href="route('forum.create.page', { id: topic.id })">
           Create
           </Link>
           <Link v-else-if="$page.props.auth.user.staff != '1' && topic.is_staff_only_posting == '0'"  class="button is-info is-rounded is-fullwidth" :href="route('forum.create.page', { id: topic.id })">
           Create
           </Link>
           </div>
          <aside class="menu">
          <p class="menu-label">Official</p>
          <ul class="menu-list">
           <li v-for="Official in section_one">
            <Link :href="route('forum.page', { id: Official.id })">
            <i v-if="Official.is_staff_only_posting == '1'" class="fas fa-lock"></i>&nbsp;{{ Official.name }}
            </Link>
           </li>
          <p class="menu-label">Community</p>
           <li v-for="Community in section_two">
            <Link :href="route('forum.page', { id: Community.id })">
            {{ Community.name }}
            </Link>
           </li>
          <p class="menu-label">Serious</p>
           <li v-for="Serious in section_three">
            <Link :href="route('forum.page', { id: Serious.id })">
            {{ Serious.name }}
            </Link>
           </li>
          </ul>
         </aside>
        </span>
       </div>
   <div class="column is-9">
       <span slot="primary">
       <div class="box" >
       <article class="media is-align-items-center" v-for="post in posts.data">
       <div class="media-left">
       <figure class="headshot image is-64x64">
       <img class="is-rounded" src="/props/aeo_headshot.png" alt="Avatar Render">
     </figure>
  </div> 
  <div class="media-content">
    <div class="content">
     <div class="is-size-6">  
     <Link class="is-link" href="">{{ post.name }}</Link>
   </div> <small>Made by <Link :href="route('user.profile', { username: post.username })" class="">{{ post.username }}</Link>,
   <span class="has-text-weight-semibold tooltip is-tooltip-top" data-tooltip="Thu Oct 08 2020 03:58:33 GMT-0400">a year ago</span> <br> Last reply by <Link :href="route('user.profile', { username: post.username })">F0X</Link>, <span class="has-text-weight-semibold tooltip is-tooltip-top" data-tooltip="Thu Oct 08 2020 04:06:53 GMT-0400">a year ago</span>
   </small>
   </div>
         </div> 
        </article>
       </div>
       </span>
     </div>
     </div>
   </section>
 </div>
</Layout>
</template>
<script>

export default {
    props: {
        topic: Object,
        posts: Object,
        section_one: Object,
        section_two: Object,
        section_three: Object,
    },
}
</script>