<script setup>
import Layout from '@/Layouts/Layout.vue';
import { Head, Link, useForm } from '@inertiajs/vue3';

const form = useForm({
    id: '',
    title: '',
    body: '',
});

const submit = () => {
    form.transform(data => ({
        ...data,
        remember: form.remember ? 'on' : '',
    })).post(route('forum.create.validate'), {
        onFinish: () => form.reset('message'),
    });
};

</script>

<template>
<Layout title="Create a post">
<div class="container">
<section class="section">
<div class="container">
  <div class="columns">
         <div class="column is-3">
           <span slot="secondary">
           <div class="title">{{ topic.name }}</div>
           <div class="subtitle is-6 has-text-grey-light">{{ topic.description }}</div>
          <aside class="menu">
          <p class="menu-label">Official</p>
          <ul class="menu-list">
           <li v-for="Official in section_one">
            <Link :href="route('forum.page', { id: Official.id })">
            <i v-if="Official.is_staff_only_posting == '1'" class="fas fa-lock"></i>&nbsp;{{ Official.name }}
            </Link>
           </li>
          <p class="menu-label">Community</p>
           <li v-for="Community in section_two">
            <Link :href="route('forum.page', { id: Community.id })">
            {{ Community.name }}
            </Link>
           </li>
          <p class="menu-label">Serious</p>
           <li v-for="Serious in section_three">
            <Link :href="route('forum.page', { id: Serious.id })">
            {{ Serious.name }}
            </Link>
           </li>
          </ul>
         </aside>
        </span>
       </div>
    <div class="column is-9">
    <div class="title">Create</div>
    <div class="subtitle is-6 has-text-grey-light">Create an eye-catching post. Make sure you post in the appropiate sub-forum and that your post does not break any site rules.</div>
      <div class="box">
        <form @submit.prevent="submit">
         <input type="hidden" name="id" value="{{ topic.id }}">
          <div class="field">
            <div class="control">
              <div class="has-text-weight-bold">Post Title</div>
              <input class="input" type="text" name="title" v-model="form.title" placeholder="Title" maxlength="64">
            </div>
          </div>
          <div class="field">
            <div class="control">
               <div class="has-text-weight-bold">Post Content</div>
              <textarea class="textarea" name="body" v-model="form.body" placeholder="Body" maxlength="4096"></textarea>
            </div>
          </div>
          <div class="field">
            <div class="control">
              <button class="button is-link" :disabled="form.processing">Create</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
</section>
</div>
</Layout>
</template>

<script>

export default {
    props: {
        topic: Object,
        title: Object,
        id: Number,
        section_one: Object,
        section_two: Object,
        section_three: Object,
    },
}
</script>