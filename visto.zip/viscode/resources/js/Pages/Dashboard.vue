<script setup>
import Layout from '@/Layouts/Layout.vue';
import { useForm } from '@inertiajs/vue3';
import Aeopage from '@/Components/Pagination.vue';

const form = useForm({
    message: '',
});

const submit = () => {
    form.transform(data => ({
        ...data,
        remember: form.remember ? 'on' : '',
    })).post(route('my.dashboard.validate'), {
        onFinish: () => form.reset('message'),
    });
};

</script>

<template>
<Layout title="Dashboard">
<div class="container">
 <section class="section">
  <div class="columns is-centered">
   <div class="column is-3">
   <div class="dashboard-card card">
   <div class="dashboard-header has-background-info">
   <div class="dashboard-avatar">
   <img class="" src="/props/aeo_headshot.png" alt="Avatar Render"> 
   </div>
  </div>
    <div class="dashboard-card-body mt-4">
    <div class="is-size-6 has-text-centered has-text-weight-semibold">{{ $page.props.auth.user.name }}</div>
    </div>
  </div>
</div>

<div class="column is-7">
 <div class="block">
 <form @submit.prevent="submit">
  <fieldset>
  <div class="field has-addons mb-0">
  <div class="control is-expanded">
  <input type="text" class="input" id="message" v-model="form.message" placeholder="What's up?">
  <div v-if="form.errors.message">{{ form.errors.message }}</div>
  </div> 
  <div class="control">
  <button class="button is-info is-rounded" :disabled="form.processing">Update</button>
  </div>
 </div>   
  </fieldset>
 </form>
</div>
   <div class="block">
   
    <article class="media is-align-items-center" v-for="status in slist.data" :key="status.id">
     <div class="media-left">
     <Link :href="route('user.profile', { username: status.name })">
      <figure class="headshot image is-48x48">
      <img class="is-rounded" src="/props/aeo_headshot.png" alt="Avatar Render"> 
      <div class="status-circle-online"></div>
      </figure>
     </Link>
     </div> 
      <div class="box has-shadow-small media-content">
       <div class="content">
        <div class="is-size-7 has-text-grey-light">
         <Link :href="route('user.profile', { username: status.name })">{{ status.name }}</Link>&nbsp; 
          <span class="has-text-weight-semibold tooltip is-tooltip-top" data-tooltip="{{ status.created_at }}">{{ status.DateHum }}</span>
          </div>{{ status.message }}</div>
          </div>
      </article>
      <Aeopage :links="slist.links" />
</div>
</div>
</div>
</section>
</div>
</Layout>
</template>

<script>
export default {
    props: {
        slist: Object,
    },
}
</script>