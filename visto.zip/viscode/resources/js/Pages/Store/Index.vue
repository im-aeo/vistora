<script setup>
import Layout from '@/Layouts/Layout.vue';
</script>

<template>
<Layout title="Store">
 <div class="container">
     <section class="section">
       <div class="columns">
         <div class="column is-3">
           <span slot="secondary">
           <div class="title">Store</div>
           <div class="subtitle is-6 has-text-grey-light">Skin through numerous virtual items to create your own perfect & unique identity</div>
         <aside class="menu">
          <p class="menu-label">Basic</p>
            <ul class="menu-list">
           <li>
            <a href="https://vistora.xyz/forum/1">
            Hats
            </a>
           </li>
           <li>
            <a href="https://vistora.xyz/forum/1">
            Faces
            </a>
           </li>
           <li>
            <a href="https://vistora.xyz/forum/1">
            Gears
            </a>
           </li>
           <li>
            <a href="https://vistora.xyz/forum/1">
            Shirts
            </a>
           </li>
           <li>
            <a href="https://vistora.xyz/forum/1">
            Pants
            </a>
           </li>
            <p class="menu-label">Extra</p>
            <li>
            <a href="https://vistora.xyz/forum/1">
            Heads
            </a>
           </li>
           <li>
            <a href="https://vistora.xyz/forum/1">
            Accessories
            </a>
           </li>
             <li>
            <a href="https://vistora.xyz/forum/1">
            Crates
            </a>
           </li>
          </ul>
         </aside>
        </span>
       </div>
     </div>
   </section>
 </div>
</Layout>
</template>