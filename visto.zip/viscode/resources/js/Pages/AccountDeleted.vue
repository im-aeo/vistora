<script setup>
import Layout from '@/Layouts/Layout.vue';
import { Head, Link } from '@inertiajs/vue3';

</script>

<template>
<Layout title="Welcome">
<section class="index-hero hero is-fullheight">
      <div class="hero-body">
        <div class="container">
          <div class="columns is-centered">
            <div class="column is-12 has-text-pulled-left">
              <div class="title is-1 has-text-weight-normal mb-2">
               Your account has been deleted.
              </div>
              <div class="title is-5 has-text-grey-light has-font-weight-light mb-3">
               Farewell.
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
</Layout>
</template>