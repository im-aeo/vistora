<script setup>
import Layout from '@/Layouts/Layout.vue';
</script>

<template>
<Layout title="Discover">
 <div class="container">
   <section class="section">
     <div class="columns">
      <div class="column is-3">
      <div class="title">Discover</div>
      <div class="subtitle is-6 has-text-grey-light">Find new friends among thousands of users</div>
      <aside class="menu">
      <p class="menu-label">Navigate</p>
      <ul class="menu-list">
       <li>
       <a class="is-active">All</a>
       </li>
      </ul>
     </aside>
    </div>
     <div class="column is-9">
       <nav class="level is-mobile">
       <div class="level-left">
       <div class="level-item">
       <div class="has-text-weight-semibold">Users</div>
       </div>
      </div> 
      <div class="level-right">
       <form>
       <fieldset>
       <div class="field has-addons mb-0">
       <p class="control">
       <input class="input is-small" type="text" placeholder="Search">
       </p> 
       <p class="control"><button class="button is-info is-small">Search</button></p>
       </div>
      </fieldset>
     </form>
   </div>
  </nav>
  <div class="columns is-multiline">
  
    <div class="column is-6" v-for="user in users.data" :key="user.id">
      <div class="box hover-shadow-slow">
       <article class="media is-align-items-center">
        <div class="media-left">
         <figure class="headshot image is-64x64">
         <img class="is-rounded" src="/props/aeo_headshot.png" alt="Avatar Render"> 
         </figure>
         </div> 
         <div class="media-content">
           <div class="content">
            <div class="is-size-5">
            <Link class="is-link" :href="route('user.profile', { username: user.name })">
            <span class="has-text-truncate">{{ user.name }}</span>
            </Link>
          </div> 
          <div class="is-size-7 has-text-grey-light">
          <span class="has-text-truncate">{{ user.status }}</span>
          </div>
         </div>
        </div> 
        <div class="media-right is-hidden-mobile" v-if="user.staff == '1'">
        <span class="tag is-info tooltip has-tooltip-top" data-tooltip="This user is an official Vistora staff member">Admin</span>
       </div>
      </article>
      </div>
     </div>
    </div>
   </div>
          <Aeopage v-bind:pagedata="users" v-on:page-clicked="getUserList"></Aeopage>
  </div>
 </section>
</div>
</Layout>
</template>

<script>
export default {
    props: {
        users: Object,
    },
    methods: {
        getUserList(page){
            var vm = this;
            if(page == undefined){
                var pageUrl = '/user/discover';
            }else{
                var pageUrl = '/user/discover/?page=' + page;
            }
            
            axios.get(pageUrl).then(function(response){
                if(response.data.hasOwnProperty('success')){
                    vm.users = response.data.users;
                    vm.tags = response.data.users.data;
                }
            }).catch(function(error){
                console.log(error);
            });
        }
    },
}
</script>