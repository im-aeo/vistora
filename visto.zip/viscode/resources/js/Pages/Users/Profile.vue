<script setup>
import Layout from '@/Layouts/Layout.vue';
import { Head, Link } from '@inertiajs/vue3';

</script>

<template>
<Layout title="Aeo">
<div class="container">
 <section class="section">
  <div class="columns is-centered">
    <div class="column is-3">

     <div class="box has-text-centered mb-1">
            <img src="/props/aeo.png" alt="Avatar Render">
            <hr> 
            <div class="is-size-7 has-text-grey-light is-whitespace">{{ user.bio }}</div>
            </div>
            <span slot="buttons">
            <div class="block mt-3 mb-2">
            <div class="buttons">
            <button type="submit" class="button is-info is-fullwidth">Follow</button>
            <button class="button is-info is-fullwidth">Chat</button> 
            <a href="#" class="button is-info is-fullwidth">Trade</a>
            </div>
           </div>
          </span>
          
          <div class="block">
            <span slot="statistics">
              <div class="is-size-5 has-text-weight-semibold mb-1">Statistics</div>
               <div class="box">
               <div> 
                <span class="has-text-weight-semibold">Posts</span>
                <span class="is-pulled-right">288</span>
               </div>
               <div>
                <span class="has-text-weight-semibold">Views</span>
                <span class="is-pulled-right">{{ user.views }}</span>
               </div>
               <div>
                <span class="has-text-weight-semibold">Followers</span>
                <span class="is-pulled-right">22</span>
               </div>
               <div>
                <span class="has-text-weight-semibold">Following</span>
                <span class="is-pulled-right">13</span>
               </div>
              </div>
             </span>
            </div>
           </div> 
           <div class="column is-6">
           <div class="is-size-5 has-text-weight-semibold mb-2">{{ user.name }}'s Profile
           <span class="tags is-pulled-right">
           <span class="tag is-danger tooltip has-tooltip-top is-rounded" data-tooltip="4 minutes ago">Offline</span>
           </span>
</div>
          <div class="box">
          <div class="menu-label mb-1">Status</div>
          {{ user.status }}
          <div class="menu-label mt-3 mb-1">Creation Date</div>
          <span class="tooltip has-tooltip-top" data-tooltip="2 years, 1 month ago">November 20, 2020</span>
          <div class="menu-label mt-3 mb-1">Last Seen</div>
          <span class="tooltip has-tooltip-top" data-tooltip="4 minutes ago">January 11, 2023</span>
          </div>
         </div> 
       </div>
</section>
</div>
</Layout>
</template>

<script>
export default {
    props: {
        user: Object,
    },
}
</script>