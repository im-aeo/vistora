<script setup>
import Layout from '@/Layouts/Layout.vue';
import DeleteUserForm from './Partials/DeleteUserForm.vue';
import UpdatePasswordForm from './Partials/UpdatePasswordForm.vue';
import UpdateProfileInformationForm from './Partials/UpdateProfileInformationForm.vue';
import { Head } from '@inertiajs/vue3';

defineProps({
    mustVerifyEmail: Boolean,
    status: String,
});
</script>

<template>
    <Layout title="Settings">
     <div class="container">
       <section class="section">
          <div class="columns">
          <div class="column is-3">
           <span slot="secondary">
           <div class="title">Settings</div>
           <div class="subtitle is-6 has-text-grey-light">Manage your account here</div>
           <aside class="menu">
           <p class="menu-label">The Kitchen Sink</p> 
            <ul class="menu-list">
             <li>
             <a class="is-active">Overview</a>
             </li>
             </ul>
           </aside>
          </span>
         </div>  
       <div class="column is-9">
       <span slot="primary">
       <div class="title">Profile Information</div>
       <div class="subtitle is-6 has-text-grey-light mb-3">Crucial user variables</div>
        <div class="box">
           <UpdateProfileInformationForm
            :must-verify-email="mustVerifyEmail"
            :status="status"
            class="max-w-xl"
            />
         </div>
                <div class="box">
                    <UpdatePasswordForm class="max-w-xl" />
                </div>

                <div class="box">
                   <label class="label">Account Deletion</label>
                   <div class="field help has-text-grey-light">Click the button to delete your account. You cannot recover your account unless you contact a staff member.</div>
                    <DeleteUserForm class="max-w-xl" />
                </div>
           </span>
          </div>
        </div>
       </section>
      </div>
    </Layout>
</template>
