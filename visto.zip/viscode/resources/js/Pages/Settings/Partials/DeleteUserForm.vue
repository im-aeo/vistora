<script setup>
import { useForm } from '@inertiajs/vue3';
import { nextTick, ref } from 'vue';

const confirmingUserDeletion = ref(false);
const passwordInput = ref(null);

const form = useForm({
    password: '',
});

const confirmUserDeletion = () => {
    confirmingUserDeletion.value = true;

    nextTick(() => passwordInput.value.focus());
};

const deleteUser = () => {
    form.delete(route('user.settings.destroy'), {
        preserveScroll: true,
        onSuccess: () => closeModal(),
        onError: () => passwordInput.value.focus(),
        onFinish: () => form.reset(),
    });
};

const closeModal = () => {
    confirmingUserDeletion.value = false;

    form.reset();
};
</script>

<template>
                <button class="button is-danger" @click="confirmUserDeletion">Delete Account</button>

        <div v-bind:class="{ 'is-active': confirmingUserDeletion }" class="modal" @close="closeModal">
          <form @submit.prevent="submit">
           <div class="modal-background"></div>
             <div class="modal-card">
              <header class="modal-card-head">
               <p class="modal-card-title">Are you sure you want to delete your account?</p>
                <button class="delete" @click="closeModal"></button>
                </header>
                <section class="modal-card-body">
                 Once your account is deleted, all of its resources and data will be permanently deleted. Please enter your password to confirm you would like to permanently delete your account.
                    <div class="field">
                     <div class="control">
                     <input
                        id="password"
                        ref="passwordInput"
                        v-model="form.password"
                        type="password"
                        class="input is-danger"
                        placeholder="Password"
                        @keyup.enter="deleteUser"
                    />
                     </div>
                    </div>
                    <div :message="form.errors.password" class="mt-2" />
                 </section>
                <footer class="modal-card-foot">
                    <button class="button" @click="closeModal">Cancel</button>

                    <button
                        class="button is-danger"
                        :disabled="form.processing"
                        @click="deleteUser"
                    >
                        Close Account
                    </button>
                    </footer>
                </div>
                </form>
            </div>
</template>
