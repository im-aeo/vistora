<script setup>
import Layout from '@/Layouts/Layout.vue';
import { Head, Link } from '@inertiajs/vue3';

</script>

<template>
<Layout title="Example Page Layout">
<div class="container">
 <section class="section">

</section>
</div>
</Layout>
</template>