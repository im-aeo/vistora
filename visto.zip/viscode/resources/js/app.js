import './bootstrap';

//light mode
//import '../css/app_light.css';
//import '../css/custom_light.css';

// dark mode
import '../css/app.css';
import '../css/custom.css';

import '../css/tooltips.min.css';
import { createApp, h } from 'vue';
import { createInertiaApp, Head, Link } from '@inertiajs/vue3';
import Pagination from '../js/Components/Pagination.vue';
import { resolvePageComponent } from 'laravel-vite-plugin/inertia-helpers';
import { ZiggyVue } from '../../vendor/tightenco/ziggy/dist/vue.m';

const appName = window.document.getElementsByTagName('title')[0]?.innerText || 'Vistora';

createInertiaApp({
    // Vistora Progress Bar
    progress: {color: '#7957D5', includeCSS: true},
    // Title
    title: (title) => `${title} - ${appName}`,
    // PAges
    resolve: (name) => resolvePageComponent(`./Pages/${name}.vue`, import.meta.glob('./Pages/**/*.vue')),
    // App Renderer
    setup({ el, App, props, plugin }) {
        createApp({ render: () => h(App, props) })
            .use(plugin)
            .use(ZiggyVue, Ziggy)
            .component('Head', Head)
            .component('Link', Link)
            .component('Aeopage', Pagination)
            .mount(el);
    },
});



